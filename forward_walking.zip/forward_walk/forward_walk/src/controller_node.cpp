// #include "controller.h"

// int main(int argc, char * argv[])
// {
//     rclcpp::init(argc, argv);
//     auto node = rclcpp::Node::make_shared("minicar_controller_node");

//     float control_frequency = 500.;

//     std::string topic_wheel_state, topic_wheel_command, topic_imu;

//     node->declare_parameter("topic_wheel_state", "/joint_states");
//     node->declare_parameter("topic_wheel_command", "/velocity_controller/commands");
//     node->declare_parameter("topic_imu", "/imu");

//     node->get_parameter("topic_wheel_state", topic_wheel_state);
//     node->get_parameter("topic_wheel_command", topic_wheel_command);
//     node->get_parameter("topic_imu", topic_imu);

//     RCLCPP_INFO(node->get_logger(), "Using joint state topic: %s", topic_wheel_state.c_str());
//     RCLCPP_INFO(node->get_logger(), "Using joint command topic: %s", topic_wheel_command.c_str());
//     RCLCPP_INFO(node->get_logger(), "Using IMU topic: %s", topic_imu.c_str());

//     // Subscribers
//     auto joint_sub = node->create_subscription<sensor_msgs::msg::JointState>(topic_wheel_state, 10, wheel_callback);
//     auto imu_sub = node->create_subscription<sensor_msgs::msg::Imu>(topic_imu, 10, imu_callback);

//     // Publisher
//     auto velocity_pub = node->create_publisher<std_msgs::msg::Float64MultiArray>(topic_wheel_command, 10);

//     rclcpp::Rate rate(control_frequency);
//     rclcpp::Time start_time = node->now();

//     while (rclcpp::ok()) {

//         rclcpp::spin_some(node);

//         std_msgs::msg::Float64MultiArray cmd;
//         cmd.data.resize(2);
//         // for (size_t i = 0; i < cmd.data.size(); ++i) { cmd.data[i] = 10; }
//         cmd.data[0] = 10;  
//         cmd.data[1] = -10;  

//         velocity_pub->publish(cmd);

//         RCLCPP_INFO(node->get_logger(), "orientation %f %f %f", orientation_(0), orientation_(1), orientation_(2));
    
//         rate.sleep();
//     }
//     rclcpp::shutdown();

//     return 0;
// }

// void imu_callback(const sensor_msgs::msg::Imu::SharedPtr msg)
// {
//     // Quaternion
//     Eigen::Quaterniond quat(msg->orientation.w, msg->orientation.x, msg->orientation.y, msg->orientation.z);

//     // Angular Velocity [rad/s]
//     angular_velocity_(0) = msg->angular_velocity.x; 
//     angular_velocity_(1) = msg->angular_velocity.y;
//     angular_velocity_(2) = msg->angular_velocity.z;

//     // Linear Accceleration [m/s^2]
//     linear_acceleration_(0) = msg->linear_acceleration.x;
//     linear_acceleration_(1) = msg->linear_acceleration.y;
//     linear_acceleration_(2) = msg->linear_acceleration.z;

//     // Rotation Matrix
//     rotation_matrix_ = quat.toRotationMatrix();

//     // Euler Angle [rad]
//     orientation_(1) = std::asin(-rotation_matrix_(2, 0));
//     if (std::cos(orientation_(1)) != 0) { // Check for edge cases
//         orientation_(0) = std::atan2(rotation_matrix_(2, 1), rotation_matrix_(2, 2));
//         orientation_(2) = std::atan2(rotation_matrix_(1, 0), rotation_matrix_(0, 0));
//     } 
//     else { // Gimbal lock case (cos(pitch) == 0),  In this case, we can set roll to 0 and calculate yaw differently
//         orientation_(0) = 0.0;
//         orientation_(2) = std::atan2(-rotation_matrix_(0, 1), rotation_matrix_(1, 1));
//     }
// }

// void wheel_callback(const sensor_msgs::msg::JointState::SharedPtr msg)
// {
//     q_(0) = msg->position[0];
//     q_(1) = msg->position[1];
//     dq_(0) = msg->velocity[0];
//     dq_(1) = msg->velocity[1];
//     effort_(0) = msg->effort[0];
//     effort_(1) = msg->effort[1];
// }