// xsens_fall_detector.cpp
#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/imu.hpp>
#include <geometry_msgs/msg/quaternion_stamped.hpp>
#include <robot_msgs/msg/fall_result.hpp>

#include <tf2/LinearMath/Quaternion.h>
#include <tf2/LinearMath/Matrix3x3.h>

#include <cmath>
#include <chrono>

using std::placeholders::_1;
using namespace std::chrono_literals;

class XsensFallDetector : public rclcpp::Node
{
public:
  XsensFallDetector()
  : Node("xsens_fall_detector"),
    has_ori(false),
    has_imu(false),
    last_stable_time_sec_(0.0),
    prev_yaw_deg_(0.0)
  {
    // ====== Parameters ======
    // 타이머 주기(dt)와 LPF 컷오프(Hz). alpha = dt / (tau + dt), tau = 1/(2*pi*fc)
    declare_parameter<double>("timer_hz", 100.0);               // 필터/판단 주기
    declare_parameter<double>("cutoff_ypr_hz", 6.0);            // roll/pitch/yaw 컷오프
    declare_parameter<double>("cutoff_az_hz", 6.0);             // az 컷오프
    declare_parameter<double>("fall_time_sec", 1.0);            // 조건 지속 시간


    declare_parameter<double>("stable_yaw_save_sec", 0.5);      // 안정구간 지속 시 yaw 저장
    declare_parameter<bool>("throttle_log", true);              // 로그 스팸 방지

    const double timer_hz       = get_parameter("timer_hz").as_double();
    cutoff_ypr_hz_              = get_parameter("cutoff_ypr_hz").as_double();
    cutoff_az_hz_               = get_parameter("cutoff_az_hz").as_double();
    fall_time_sec_              = get_parameter("fall_time_sec").as_double();
    stable_yaw_save_sec_        = get_parameter("stable_yaw_save_sec").as_double();
    throttle_log_               = get_parameter("throttle_log").as_bool();

    dt_ = 1.0 / std::max(1.0, timer_hz);

    // alpha 사전계산
    alpha_ypr_ = alphaFromCutoff(cutoff_ypr_hz_, dt_);
    alpha_az_  = alphaFromCutoff(cutoff_az_hz_,  dt_);



    // ====== ROS I/O ======
    sub_quat = create_subscription<geometry_msgs::msg::QuaternionStamped>(
      "/filter/quaternion", 10, std::bind(&XsensFallDetector::onQuat, this, _1));

    sub_imu = create_subscription<sensor_msgs::msg::Imu>(
      "/imu/data", 10, std::bind(&XsensFallDetector::onImu_z, this, _1));

    pub_fall = create_publisher<robot_msgs::msg::FallResult>("/fall_result", 10);



    // 타이머: 필터 + 판단 + publish
    timer_ = create_wall_timer(
      std::chrono::duration<double>(dt_),
      std::bind(&XsensFallDetector::onTimer, this));

  }

private:
  // ====== 콜백(샘플 저장) ======
  void onQuat(const geometry_msgs::msg::QuaternionStamped::SharedPtr msg)
  {
    // quaternion -> RPY(라디안)
    tf2::Quaternion q(msg->quaternion.x, msg->quaternion.y, msg->quaternion.z, msg->quaternion.w);
    double roll, pitch, yaw;
    tf2::Matrix3x3(q).getRPY(roll, pitch, yaw);

    latest_roll_deg_  = roll * 180.0 / M_PI;
    latest_pitch_deg_ = pitch * 180.0 / M_PI;

    // yaw는 0~360도로 래핑
    double yaw_deg = fmod((yaw * 180.0 / M_PI) + 360.0, 360.0);
    latest_yaw_deg_ = yaw_deg;

    has_ori = true;
  }




  void onImu_x(const sensor_msgs::msg::Imu::SharedPtr msg)
  {
    latest_ax = msg->linear_acceleration.x;
    has_imu = true;
  }

  void onImu_y(const sensor_msgs::msg::Imu::SharedPtr msg)
  {
    latest_ay = msg->linear_acceleration.y;
    has_imu = true;
  }

  void onImu_z(const sensor_msgs::msg::Imu::SharedPtr msg)
  {
    latest_az = msg->linear_acceleration.z;
    has_imu = true;
  }



  // ====== 타이머(필터 + 판단 + publish) ======
  void onTimer()
  {
    if (!(has_ori && has_imu)) return;

    // LPF 초기화(첫 샘플로 시동)
    if (!filt_init_) {
      roll_f_  = latest_roll_deg_;
      pitch_f_ = latest_pitch_deg_;
      // yaw: cos/sin로 상태 보관 (래핑 안전)
      yawc_f_ = std::cos(latest_yaw_deg_ * M_PI / 180.0);
      yaws_f_ = std::sin(latest_yaw_deg_ * M_PI / 180.0);
      az_f_   = latest_az_;
      filt_init_ = true;
      start_time_point_ = nowSec();
      last_stable_time_sec_ = start_time_point_;
      condition_start_time_sec_ = 0.0;
      return;
    }

    // ==== 1차 LPF 적용 ====
    // roll/pitch: 일반 실수 필터
    roll_f_  = LPF1(roll_f_,  latest_roll_deg_,  alpha_ypr_);
    pitch_f_ = LPF1(pitch_f_, latest_pitch_deg_, alpha_ypr_);

    // yaw: 벡터 평균 방식 (cos,sin 각각 LPF)
    const double yaw_rad = latest_yaw_deg_ * M_PI / 180.0;
    yawc_f_ = LPF1(yawc_f_, std::cos(yaw_rad), alpha_ypr_);
    yaws_f_ = LPF1(yaws_f_, std::sin(yaw_rad), alpha_ypr_);
    // 재정규화(드리프트 방지)
    const double norm = std::hypot(yawc_f_, yaws_f_);
    if (norm > 1e-6) {
      yawc_f_ /= norm;
      yaws_f_ /= norm;
    }
    double yaw_f_deg = std::fmod((std::atan2(yaws_f_, yawc_f_) * 180.0 / M_PI) + 360.0, 360.0);

    // az
    az_f_ = LPF1(az_f_, latest_az_, alpha_az_);



    // ==== 안정구간이면 yaw 저장 ====
    if (std::abs(roll_f_) < 45.0 && std::abs(pitch_f_) < 30.0) {
      if ((now - last_stable_time_sec_) > stable_yaw_save_sec_) {
        prev_yaw_deg_ = yaw_f_deg;
        last_stable_time_sec_ = now;
        if (!throttle_log_) {
          RCLCPP_INFO(get_logger(), "안정된 yaw 저장: %.1f°", prev_yaw_deg_);
        }
      }
    } else {
      last_stable_time_sec_ = now;
    }

    // ==== Publish ====
    robot_msgs::msg::FallResult out;
    out.fall_detect = fall_detected_;
    out.prev_yaw_deg = static_cast<int32_t>(std::lround(prev_yaw_deg_));
    pub_fall->publish(out);


  // ====== 유틸/수학 ======
  static inline double alphaFromCutoff(double cutoff_hz, double dt)
  {
    // tau = 1/(2*pi*fc), alpha = dt/(tau + dt)
    if (cutoff_hz <= 0.0) return 1.0; // 매우 강한 필터(=즉시 최신값) 방지 차원에서 1.0은 no-filter와 반대지만,
                                      // 여기선 안전하게 "즉시 따라감"으로 처리.
    const double tau = 1.0 / (2.0 * M_PI * cutoff_hz);
    return dt / (tau + dt);
  }

  static inline double LPF1(double y_prev, double x_now, double alpha)
  {
    // y = y_prev + alpha*(x - y_prev) = (1-alpha)*y_prev + alpha*x
    return y_prev + alpha * (x_now - y_prev);
  }

  double nowSec() const
  {
    return this->now().seconds();
  }

  // ====== Members ======
  // 최신 샘플
  bool has_ori{false}, has_imu{false};
  double latest_roll_deg_{0.0}, latest_pitch_deg_{0.0}, latest_yaw_deg_{0.0};
  double latest_ax{0.0};
  double latest_ay{0.0};
  double latest_az{0.0};



  // LPF 상태
  bool filt_init_;
  double roll_f_{0.0}, pitch_f_{0.0};
  double yawc_f_{1.0}, yaws_f_{0.0}; // yaw는 cos/sin 상태로 보관
  double az_f_{0.0};

  // 판정 상태

  double condition_start_time_sec_;
  double last_stable_time_sec_;
  double prev_yaw_deg_;

  // 파라미터/상수
  double dt_;
  double cutoff_ypr_hz_, cutoff_az_hz_;
  double alpha_ypr_, alpha_az_;
  double stable_yaw_save_sec_;
  bool   throttle_log_;
  double start_time_point_{0.0};

  // ROS I/O
  rclcpp::Subscription<geometry_msgs::msg::QuaternionStamped>::SharedPtr sub_quat;
  rclcpp::Subscription<sensor_msgs::msg::Imu>::SharedPtr sub_imu;
  rclcpp::TimerBase::SharedPtr timer_;
};

int main(int argc, char** argv)
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<XsensFallDetector>());
  rclcpp::shutdown();
  return 0;
}
