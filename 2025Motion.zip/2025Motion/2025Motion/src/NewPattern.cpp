#include <cmath>
#include <algorithm>
#include "NewPattern.hpp"

using namespace Eigen;
using namespace std;
#define deg2rad 0.017453292519943
#define rad2deg 57.295779513082323
#define PI 3.141592653589793



// === 로봇 파라미터 값 정의 ===
// ※ 프로젝트 값에 맞게 조정하세요.
const double ROBOT_WIDTH         = 0.25;  // [m] 예: 좌우 발 간격 절반 합 0.25
const double ROBOT_STAND_HEIGHT  = 0.30;  // [m] 예: 서있는 COM 높이
const double ROBOT_SWING_HEIGHT  = 0.05;  // [m] 예: 스윙 발 들어올림

// === 전역 패턴 상태/보간 헬퍼 정의 ===
gait::PatternState Pattern_;
gait::Quintic      GC_;


// ---- 선속도(latest) 구독 초기화 ----
void Trajectory::InitROS(const rclcpp::Node::SharedPtr& node, const std::string& latest_topic)
{
    // linvel_store 가 transient_local 로 마지막 1개를 보존하므로,
    // 우리도 같은 QoS로 구독하면 노드가 늦게 떠도 최신 1개 즉시 수신 가능
    auto qos = rclcpp::QoS(1).reliable().transient_local();

    vy_sub = node->create_subscription<std_msgs::msg::Float32>(latest_topic, qos,
		[this](const std_msgs::msg::Float32::SharedPtr m)
        {
			act_com_y_vel_.store(static_cast<double>(m->data), std::memory_order_relaxed);
    		have_linvel_.store(true, std::memory_order_relaxed);
        }
	);
}


//SwingPhase = (now_T - swingstart_T) / swingtime

void Trajectory::SwingLegController()
{
    TempXY = RaibertHeuristic(Ref.CoM_.vel.segment(0,3), Act.CoM_.vel.segment(0,3), shared_memory_->ang_vel_target[2]); 
	double vy = have_linvel_.load() ? act_com_y_vel_.load() : 0.0;
	tempY = CalcCapturePoint(-vy, 0.5);

	// 0 = left, 1 = right
	Eigen::Vector2d baseX, baseY;
	baseX[0] = 0.0;
	baseX[1] = 0.0;
	baseY[0] = -( ROBOT_WIDTH / 2.0 );
	baseY[1] = ( ROBOT_WIDTH / 2.0 );

    Eigen::Vector2d targetX = baseX + TempXY.row(0).transpose();
    Eigen::Vector2d targetY = baseY + TempXY.row(1).transpose() + tempY; // tempY는 Y축으로의 오프셋

    ref_foot_pos = QuinticSwingTrajectory(targetX, targetY, Pattern_.SwingPhase);

    Ref.LL_.pos = ref_foot_pos.col(0);
    Ref.RL_.pos = ref_foot_pos.col(1);

    CalcSwingForceControl(true); // false: CTC 모드가 아닌 일반 모드로 스윙 포스 계산
	
}

Eigen::Matrix<double,2,2>  Trajectory::RaibertHeuristic(const Eigen::Vector3d& RefVel, const Eigen::Vector3d& ActVel, double omega_cmd) 
{
    Eigen::Matrix<double,2,2> RaibertOffset;
    double omega0 = std::sqrt(ROBOT_STAND_HEIGHT / 9.81);
    double halfT  = Pattern_.time_st * 0.5;

    // 기본 Raibert heuristic
    double dx_lin = RefVel(0) * halfT + omega0 * (ActVel(0) - RefVel(0));
    double dy_lin = RefVel(1) * halfT + omega0 * (ActVel(1) - RefVel(1));

    // 모든 다리에 동일하게 적용
    RaibertOffset.row(0).setConstant(dx_lin);  // X-offset
    RaibertOffset.row(1).setConstant(dy_lin);  // Y-offset
    return RaibertOffset;
}

Eigen::Vector2d Trajectory::CalcCapturePoint(double Act_Com_y_vel, double CP_ratio)
{
    double LPF_y_vel = Act_Com_y_vel;
    double cp_scale = CP_ratio * std::sqrt(ROBOT_STAND_HEIGHT / 9.81);

    Eigen::Vector2d swingMask;
    for (int i = 0; i < 2; ++i) swingMask(i) = (Pattern_.SW_FLAG[i] == 1 ? 1.0 : 0.0);

    Eigen::Vector2d now_cp = Eigen::Vector2d::Constant(LPF_y_vel);

    CP_Dist_Upper = CP_Dist_Upper.cwiseMax(now_cp).cwiseProduct(swingMask);
    CP_Dist_Lower = CP_Dist_Lower.cwiseMin(now_cp).cwiseProduct(swingMask);

    Eigen::Vector2d absU = CP_Dist_Upper.cwiseAbs();
    Eigen::Vector2d absL = CP_Dist_Lower.cwiseAbs();
    Eigen::Vector2d chosen ;
	for (int i = 0; i < 2; ++i) chosen(i) = (absU.array(i) > absL.array(i)) ? CP_Dist_Upper(i) : CP_Dist_Lower(i);
    
	Eigen::Vector2d CapturePoint = chosen * cp_scale;
    return CapturePoint;
}


// IMU에서 바로 가져다 쓰는 래퍼
Eigen::Vector2d Trajectory::CalcCapturePointFromIMU(double CP_ratio)
{
    // 최소 변경: 바디 프레임 Y속도 사용
    const double vy_body = static_cast<double>(sensor_->GetVelocityCompY());

    // 만약 월드 프레임 Y속도를 쓰고 싶다면 (권장):
    // const double vy_world = static_cast<double>(sensor_->GetVelocityCompWorldY());
    // return CalcCapturePoint(vy_world, CP_ratio);

    return CalcCapturePoint(vy_body, CP_ratio);
}

//[ x, y, z ] for L,R
Eigen::Matrix<double,3,2>  Trajectory::QuinticSwingTrajectory(Eigen::Vector2d& RefX,Eigen::Vector2d& RefY, double SwingPhase[2])
{
    Eigen::Matrix<double,3,2>  swing_trajectory(3,2);

    for (int leg = 0; leg < 2; ++leg) {
    // 스탠스→스윙 전환 시 시작 위치 저장
    	if (Pattern_.old_SW_FLAG[leg] == 0 && Pattern_.SW_FLAG[leg] == 1) {
    		tempXtraj[leg] = foot_pos(_X_, leg);
        	tempYtraj[leg] = foot_pos(_Y_, leg);
        	tempZtraj[leg] = foot_pos(_Z_, leg);
    	}

    	if (Pattern_.SW_FLAG[leg] == 1) {
        	// Normalize phase to [0,1]
        	double tau = std::clamp(SwingPhase[leg], 0.0, 1.0);

        	// Interpolate X and Y between start (temp*traj) and target (Ref*)
        	double x = tempXtraj[leg] + (RefX[leg] - tempXtraj[leg]) * GC_.quintic(tau);
        	double y = tempYtraj[leg] + (RefY[leg] - tempYtraj[leg]) * GC_.quintic(tau);
        	double z;
        	
			if (tau < 1.0 / 3.0) {
            	// rising phase
            	double phase = tau * 3.0;
            	z = tempZtraj[leg] + ROBOT_SWING_HEIGHT * GC_.quintic(phase);
            } else{
                // falling phase
                double phase = (tau - 1.0 / 3.0) * 1.5;
                z = tempZtraj[leg] + ROBOT_SWING_HEIGHT * (1.0 - GC_.quintic(phase));
            }
			swing_trajectory(0, leg) = x;
			swing_trajectory(1, leg) = y;
			swing_trajectory(2, leg) = z;
            
			Pattern_.old_SW_FLAG[leg] = Pattern_.SW_FLAG[leg];

        }
               
        else if (Pattern_.SW_FLAG[leg] == 0) {
            swing_trajectory(0, leg) = Pattern_.stanceXtraj[leg];
            swing_trajectory(1, leg) = Pattern_.stanceYtraj[leg];
            swing_trajectory(2, leg) = Pattern_.stanceZtraj[leg];
            Pattern_.old_SW_FLAG[leg] = 0;
            continue;
        }
    }
    return swing_trajectory;
}








#include "BRP_Kinematics.hpp"
#include "NewPattern2.hpp"
#include <cmath>
#include <algorithm>
#include <vector>
#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/float32.hpp>
using namespace Eigen;
using namespace std;
using namespace BRP_Kinematics;
#define deg2rad 0.017453292519943
#define rad2deg 57.295779513082323
#define PI 3.141592653589793




Trajectory::Trajectory()
{
	walkfreq = 1.48114; // 1초 걸음 수 (보행 주파수 Hz)
	walktime = 2 / walkfreq; // 왼발 오른발 나누어 두번 걸으므로..!
	freq = 100; // 제어 루프의 주파수!
	walktime_n = walktime * freq; // 한 걸음동안 제어 루프가 몇 번 도는지 (샘플 수)!
	del_t = 1 / freq; // 제어루프의 시간 간격!
	z_c = 1.2 * 0.28224;  // CoM 높이 -> 1.2는 scale factor!
	g = 9.81; // 중력가속도!
	T_prev = 1.5; // Preview 제어 시간!
	NL = T_prev * freq; // Preview 샘플 수!
	A << 1, del_t, del_t * del_t / 2, // 시스템의 상태 : 위치 속도 가속도
		0, 1, del_t,
		0, 0, 1;
	B << del_t * del_t * del_t / 6, del_t * del_t / 2, del_t; // 입력 행렬 - 가속도를 제어 입력 취급
	C << 1, 0, -z_c / g; // CoM 위치와 가속도로 ZMP 계산
	
	
	////////////////// 가중치 행렬 //////////////////
	Qe = 1; // ZMP 오차에 대한 가중치
	Qx = Matrix3d::Zero(); // 상태 가중치 (위치, 속도, 가속도에 대한 penalty=0)
	Q_p = Matrix4d::Zero(); // Preview 제어용 결합 가중치 행렬
	Q_p << Qe, 0, 0, 0,
		0, Qx(0, 0), Qx(0, 1), Qx(0, 2),
		0, Qx(1, 0), Qx(1, 1), Qx(1, 2),
		0, Qx(2, 0), Qx(2, 1), Qx(2, 2);	// zmp 오차와 상태 가중치 조합 행렬 
	R << pow(10, -6);
	I_p << 1, 0, 0, 0;
	
	//// Preview 제어용 B,A 행렬 확장 //////
	B_p.row(0) = C * B;
	B_p.row(1) = B.row(0);
	B_p.row(2) = B.row(1);
	B_p.row(3) = B.row(2);	// ZMP 오차를 포함한 입력 행렬

	F_p.row(0) = C * A;
	F_p.row(1) = A.row(0);
	F_p.row(2) = A.row(1);
	F_p.row(3) = A.row(2);	// ZMP 오차를 포함한 상태 행렬

	A_p = Matrix4d::Identity();
	A_p.block<4, 3>(0, 1) = F_p;	// Preview 제어용 확장 상태 행렬

	K_p << 41.1035354770549, 824.198546618308, 163.877879931218, 0.866971302114951,
		824.198546618308, 17489.6862079445, 3483.96465227876, 19.6487374770632,
		163.877879931218, 3483.96465227876, 694.154076281009, 3.94329494961909,
		0.866971302114951, 19.6487374770632, 3.94329494961909, 0.0282399782535132;		// 미리 계산된 LQR Gain 행렬

	/////////// Preview Controller Gain Calculation /////////////
	Gi = (R + B_p.transpose() * K_p * B_p).inverse() * B_p.transpose() * K_p * I_p;		// 오차누적에 대한 이득 (zmp 오차 적분 -> 제어입력 변환)
	Gx = (R + B_p.transpose() * K_p * B_p).inverse() * B_p.transpose() * K_p * F_p;		// 현재 상태에 대한 이득
	Gd = MatrixXd::Zero(NL, 1);		// Preview Horizon에 대한 feedforward 이득
	Ac_p = A_p - B_p * (R + B_p.transpose() * K_p * B_p).inverse() * B_p.transpose() * K_p * A_p;
	zmp_err_int = 0;	// ZMP 오차 적분값 초기화
	u_prev = 0;		// 이전 제어 입력 초기화
	step = 0.05;	// 한 스텝 거리
	step_n = 0;		
	sim_n = 0;
	sim_time = 0;	// 시뮬레이션 관련 카운터 초기화
	Angle_trajectorty_turn << 0, 0, 0, 0, 0, 0;	
	Angle_trajectorty_back << 0, 0, 0, 0, 0, 0;		// 보행 중 회전 및 후진 동작용 궤적 초기화

	XStep << 0, 0, 0, 0, 0, 0;
	XStride << 0, 0, 0, 0, 0, 0;		// 보행 스텝 별 위치 및 보폭 값 초기화
};

void Trajectory::Change_Freq(double f)		// 보폭 속도를 조절할때 사용
{
	walktime = f / walkfreq;
	walktime_n = walktime * freq;
}		// 외부 인자 f를 기준으로 walktime(보행주기), walktime_n(제어 샘플 수) 다시 계산







// === CP 기반 Raibert: 설정/입력/계산 ===
void Trajectory::SetRaibertCP(double ratio, double vy_alpha, double dy_limit)
{
    CP_ratio     = ratio;
    vy_lpf_alpha = vy_alpha;
    CP_dy_limit  = dy_limit;
}

void Trajectory::UpdateIMUYVel(double vy_world)
{
    // 1차 LPF
    vy_lpf = (1.0 - vy_lpf_alpha) * vy_lpf + vy_lpf_alpha * vy_world;
}

double Trajectory::CPdy() const
{
    const double omega0 = std::sqrt(g / z_c);
    double dy = CP_ratio * (vy_lpf / omega0);
    if (dy >  CP_dy_limit) dy =  CP_dy_limit;
    if (dy < -CP_dy_limit) dy = -CP_dy_limit;
    return dy;
}

void Trajectory::ReserveCPSeq()
{
    dy_cp_seq_.assign(static_cast<size_t>(std::max(0, (int)step_n)), 0.0);
}

void Trajectory::SetCPForStep(int k, double vy_world)
{
    if (k < 0 || k >= (int)dy_cp_seq_.size()) return;
    const double omega0 = std::sqrt(g / z_c);
    double dy = CP_ratio * (vy_world / omega0);
    dy = std::clamp(dy, -CP_dy_limit, CP_dy_limit);
    dy_cp_seq_[k] = dy;
}

Eigen::MatrixXd Trajectory::BuildRF_y_with_CP(double L0) const
{
    const int N = step_n * walktime_n;
    Eigen::RowVectorXd y(N); y.setZero();
    int k = 0; // 오른발 스텝 인덱스 (RF_xsimulation의 Rfootflag 증가와 동기)
    for (int i = 0; i < N; ++i) {
        const double base = -L0; // 오른발 기본 오프셋(좌표계에 맞게 유지)
        const double dy   = (k < (int)dy_cp_seq_.size()) ? dy_cp_seq_[k] : 0.0;
        y[i] = base - dy; // 오른발은 바깥쪽(-)으로 Δy 반영 (좌표계에 따라 ± 변경 가능)
        if ((i + 1) % walktime_n == 0) {
            if (k < (int)step_n - 2) k += 1; // RF_xsimulation과 동일 조건
        }
    }
    return y;
}
Eigen::MatrixXd Trajectory::BuildLF_y_with_CP(double L0) const
{
    const int N = step_n * walktime_n;
    Eigen::RowVectorXd y(N); y.setZero();
    int k = 0; // 왼발 스텝 인덱스 (LF_xsimulation의 Lfootflag 증가와 동기)
    for (int i = 0; i < N; ++i) {
        const double base = +L0; // 왼발 기본 오프셋
        const double dy   = (k < (int)dy_cp_seq_.size()) ? dy_cp_seq_[k] : 0.0;
        y[i] = base + dy; // 왼발은 바깥쪽(+)으로 Δy 반영 (좌표계에 따라 ± 변경 가능)
       if ((i + 1) % walktime_n == 0) {
            if (k < (int)step_n - 2) k += 1;
        }
    }
    return y;
}











void Trajectory::Set_step(double a)	{ step = a; }	// 보폭 크기를 바꾸고 싶을 때 사용  

void Trajectory::Set_distance(double Goal_distance, double YPos)		// ZMP 및 CoM 궤적 생성을 위한 기준 위치 벡터 Ref_X,Ypos 설정
{ 
	step_n = (Goal_distance + 2 * step) / (2 * step);	// 스텝 수 계산
	sim_n = walktime_n * step_n;	// 시뮬레이션 프레임 수 - zmp, com 궤적 생성 수

	Ref_Xpos = VectorXd::Zero(2 * step_n);	// 전진방향 기준 위치 (보폭 기준)
	for (int i = 0; i < (2 * step_n); i++){
		if (i == 0) Ref_Xpos(i) = 0;
		else if (i < 2 * step_n - 1) Ref_Xpos(i) = step * (i - 1);
		else if (i == 2 * step_n - 1) Ref_Xpos(i) = step * (i - 2);
	}

	Ref_Ypos = VectorXd::Zero(2 * step_n);		// 좌우 보행 기준 위치
	for (int i = 0; i < (2 * step_n); i++){
		if (i < 1) Ref_Ypos(i) = 0;
		else if (i > 2 * step_n - 2) Ref_Ypos(i) = 0;
		else if ((i + 1) % 2 == 0) Ref_Ypos(i) = YPos;
		else if ((i + 1) % 2 == 1) Ref_Ypos(i) = -0.055;
	}
}

void Trajectory::Set_distance_start(double Goal_distance) // 위의 함수와 같으나, 시작할때 사용인지, 보행중 사용인지 차이
{
	step_n = (Goal_distance + 2 * step) / (2 * step);
	sim_n = walktime_n * step_n;

	Ref_Xpos = VectorXd::Zero(2 * step_n);
	for (int i = 0; i < (2 * step_n); i++){
		if (i == 0) Ref_Xpos(i) = 0;
		else if (i < 2 * step_n - 1) Ref_Xpos(i) = step * (i - 1);
		else if (i == 2 * step_n - 1) Ref_Xpos(i) = step * (i - 2);
	}

	Ref_Ypos = VectorXd::Zero(2 * step_n);
	for (int i = 0; i < (2 * step_n); i++){
		if (i < 1) Ref_Ypos(i) = 0;
		else if (i > 2 * step_n - 2) Ref_Ypos(i) = 0;
		else if ((i + 1) % 2 == 0) Ref_Ypos(i) = 0.057;
		else if ((i + 1) % 2 == 1) Ref_Ypos(i) = -0.06;
	}
}

void Trajectory::Set_distance_back(double Goal_distance)	// 뒤로 걷기를 위한,,
{
	step_n = (Goal_distance + 2 * step) / (2 * step);
	sim_n = walktime_n * step_n;

	Ref_Xpos = VectorXd::Zero(2 * step_n);
	for (int i = 0; i < (2 * step_n); i++){
		if (i == 0) Ref_Xpos(i) = 0;
		else if (i < 2 * step_n - 1) Ref_Xpos(i) = (step-0.007) * (i - 1);
		else if (i == 2 * step_n - 1) Ref_Xpos(i) = (step) * (i - 2);
	}

	Ref_Ypos = VectorXd::Zero(2 * step_n);
	for (int i = 0; i < (2 * step_n); i++){
		if (i < 1) Ref_Ypos(i) = 0;
		else if (i > 2 * step_n - 2) Ref_Ypos(i) = 0;
		else if ((i + 1) % 2 == 0) Ref_Ypos(i) = 0.055; //0.065
		else if ((i + 1) % 2 == 1) Ref_Ypos(i) = -0.05; //-0.05
	}
}

double Trajectory::Return_Step_n() { return step_n; }		// 현재 보행 거리 기준으로 계산된 step 수
int Trajectory::Return_Walktime_n() { return walktime_n; }		// 한 걸음 동안 제어 루프가 몇 번 도는지 반환
int Trajectory::Return_Sim_n() { return sim_n; }		// 전체 보행 시뮬레이션 프레임 수 (걸음 수 * walktime_n)

MatrixXd Trajectory::PreviewGd(){		// Preview control의 이득 행렬 Gd 계산
	for (int l = 0; l < NL; l++)
	{

		Matrix4d temp = Ac_p.transpose();
		for (int i = 1; i < l; i++){
			temp = temp * Ac_p.transpose();
		}
		Gd(l, 0) = (R + B_p.transpose() * K_p * B_p).inverse() * B_p.transpose() * temp * K_p * I_p;
		if (l == 0)
			Gd(l, 0) = (R + B_p.transpose() * K_p * B_p).inverse() * B_p.transpose() * K_p * I_p;
	}
	return Gd;
};

MatrixXd Trajectory::XComSimulation()		// X축 방향으로 com이 어떻게 이동해야 zmp 기준에 맞춰 움직일 수 있을지 궤적 계산
{
	PreviewGd();
	zmp_err_int = 0;
	u_prev = 0;
	int Com_flag = 0;
	float float_Com_flag = 0;
	float float_walktime_n = walktime_n;
	RowVectorXd zmp_ref(sim_n + 19);
	for (int i = 0; i < sim_n + 19; i++)
	{
		if (i < float_walktime_n) zmp_ref(i) = 0;
		else if (i > sim_n - 1) zmp_ref(i) = Ref_Xpos(2 * step_n - 1);
		else if (i < (float_Com_flag * 0.5 + 0.5) * float_walktime_n) zmp_ref(i) = Ref_Xpos(Com_flag);
		else if (i < (float_Com_flag * 0.5 + 1) * float_walktime_n) zmp_ref(i) = Ref_Xpos(Com_flag + 1);
		
		if ((i + 1) % walktime_n == 0){
			Com_flag = Com_flag + 2;
			float_Com_flag = float_Com_flag + 2;
		}
	}

	VectorXd zmp_ref_fifo(NL);
	VectorXd u(sim_n + 19);
	VectorXd zmp(sim_n + 19);
	VectorXd zmp_ref_final(sim_n + 19);
	VectorXd CP(sim_n + 19);
	MatrixXd XCom(3, sim_n + 20);
	zmp_ref_fifo.setZero();
	u.setZero();
	zmp.setZero();
	zmp_ref_final.setZero();
	CP.setZero();
	XCom.setZero();
	double w = sqrt(g / z_c);
	for (int i = 0; i < sim_n + 19; i++){
		for (int j = 0; j < NL; j++){
			if (i + j < sim_n + 19) zmp_ref_fifo[j] = zmp_ref[i + j];
			else zmp_ref_fifo[j] = zmp_ref[sim_n + 18];
		}
		u_prev = 0;
		for (int j = 0; j < NL; j++){
			u_prev += Gd(j, 0) * zmp_ref_fifo[j];
		}
		u[i] = Gi * zmp_err_int - Gx * XCom.col(i) + u_prev;
		XCom.col(i + 1) = A * XCom.col(i) + B * u[i];
		zmp[i] = C * XCom.col(i);
		zmp_err_int += (zmp_ref[i] - zmp[i]);
		CP[i] = XCom(0, i) + 1 / w * XCom(1, i);
		zmp_ref_final[i] = zmp_ref[i];
	}
	xzmp_ref = zmp_ref;
	ref_xCP = CP.block(18, 0, sim_n, 1);
	MatrixXd XCom_ = XCom.block(0, 18, 1, sim_n);
	return XCom_;
};

MatrixXd Trajectory::YComSimulation()		// Y축 방향으로 com이 어떻게 이동해야 zmp 기준에 맞춰 움직일 수 있을지 궤적 계산
{
	PreviewGd();
	zmp_err_int = 0;
	u_prev = 0;
	int Com_flag = 0;
	float float_Com_flag = 0;
	float float_walktime_n = walktime_n;
	RowVectorXd zmp_ref(sim_n + 19);

	for (int i = 0; i < sim_n + 19; i++) {
		if (i > sim_n - 1) zmp_ref(i) = 0;
		else if (i < (float_Com_flag * 0.5 + 0.5) * float_walktime_n) zmp_ref(i) = Ref_Ypos(Com_flag);
		else if (i < (float_Com_flag * 0.5 + 1) * float_walktime_n) zmp_ref(i) = Ref_Ypos(Com_flag + 1);

		if ((i + 1) % walktime_n == 0) {
			Com_flag = Com_flag + 2;
			float_Com_flag = float_Com_flag + 2;
		}
	}

	VectorXd zmp_ref_fifo(NL);
	VectorXd u(sim_n + 19);
	VectorXd zmp(sim_n + 19);
	VectorXd zmp_ref_final(sim_n + 19);
	VectorXd CP(sim_n + 19);
	MatrixXd YCom(3, sim_n + 20);
	zmp_ref_fifo.setZero();
	u.setZero();
	zmp.setZero();
	zmp_ref_final.setZero();
	CP.setZero();
	YCom.setZero();
	double w = sqrt(g / z_c);
	for (int i = 0; i < sim_n + 19; i++){
		for (int j = 0; j < NL; j++){
			if (i + j < sim_n + 19) zmp_ref_fifo[j] = zmp_ref[i + j];
			else zmp_ref_fifo[j] = zmp_ref[sim_n + 18];
		}
		u_prev = 0;
		for (int j = 0; j < NL; j++){
			u_prev = u_prev + Gd(j, 0) * zmp_ref_fifo[j];
		}
		u[i] = Gi * zmp_err_int - Gx * YCom.col(i) + u_prev;
		YCom.col(i + 1) = A * YCom.col(i) + B * u[i];
		zmp[i] = C * YCom.col(i);
		zmp_err_int += (zmp_ref[i] - zmp[i]);
		CP[i] = YCom(0, i) + 1.0 / w * YCom(1, i);
		zmp_ref_final[i] = zmp_ref[i];
	}
	yzmp_ref = zmp_ref;
	ref_yCP = CP.block(18, 0, sim_n, 1);
	MatrixXd YCom_ = YCom.block(0, 18, 1, sim_n);
	return YCom_;
}
//////////////////////////////////////////////////////////
VectorXd Trajectory::Get_xCP() {return ref_xCP;}

VectorXd Trajectory::Get_yCP() {return ref_yCP;}

RowVectorXd Trajectory::Get_xZMP() {return xzmp_ref;}

RowVectorXd Trajectory::Get_yZMP() {return yzmp_ref;}



//////////////////// 5차 방정식 궤적 계산기 /////////////////////
MatrixXd Trajectory::Equation_solver(double t0, double t1, double start, double end)
{
	Matrix<double, 6, 6> A;
	Matrix<double, 6, 1> B;
	Matrix<double, 6, 1> X;
	A << 1, t0, pow(t0, 2), pow(t0, 3), pow(t0, 4), pow(t0, 5),
		0, 1, 2 * t0, 3 * pow(t0, 2), 4 * pow(t0, 3), 5 * pow(t0, 4),
		0, 0, 2, 6 * t0, 12 * pow(t0, 2), 20 * pow(t0, 3),
		1, t1, pow(t1, 2), pow(t1, 3), pow(t1, 4), pow(t1, 5),
		0, 1, 2 * t1, 3 * pow(t1, 2), 4 * pow(t1, 3), 5 * pow(t1, 4),
		0, 0, 2, 6 * t1, 12 * pow(t1, 2), 20 * pow(t1, 3);
	B << start, 0, 0, end, 0, 0;
	X = A.colPivHouseholderQr().solve(B);
	return X;
};

double Trajectory::Sinusoidal(double t, double T, double h) {return h * 0.5 * (1 - cos(PI * t / T));}

double Trajectory::Step(double t){
	double X = XStep(0) + XStep(1) * t + XStep(2) * pow(t, 2) + XStep(3) * pow(t, 3) + XStep(4) * pow(t, 4) + XStep(5) * pow(t, 5);
	return X;
};

double Trajectory::Stride(double t){
	double X = XStride(0) + XStride(1) * t + XStride(2) * pow(t, 2) + XStride(3) * pow(t, 3) + XStride(4) * pow(t, 4) + XStride(5) * pow(t, 5);
	return X;
};

double Trajectory::XSN(double t){
	double X = Xsn(0) + Xsn(1) * t + Xsn(2) * pow(t, 2) + Xsn(3) * pow(t, 3) + Xsn(4) * pow(t, 4) + Xsn(5) * pow(t, 5);
	return X;
};

/////////////////// 발 경로 계산기 /////////////////////////////////////////

MatrixXd Trajectory::RF_xsimulation_straightwalk(){
	int sim_n = step_n * walktime_n;
	double dwalktime_n = walktime_n;
	double Rfootflag = 0;

	RowVectorXd Footpos(sim_n);
	Footpos.setZero();
	
	for (int i = 0; i < sim_n; i++)
	{
		if (i < 0.6 * dwalktime_n) Footpos[i] = 0;
		
		else if (i < 0.9 * dwalktime_n) {
			double t_rel = i - 0.6 * walktime_n;
			Footpos[i] = Sinusoidal(t_rel, walktime_n*0.3, step);
		}
		else if (i < 1.1 * dwalktime_n) Footpos[i] = step;
		else if (i < (Rfootflag + 0.6) * dwalktime_n) Footpos[i] = (2 * Rfootflag - 1) * step;
		else if (i < (Rfootflag + 0.9) * dwalktime_n) {
			double t_rel = i - (0.6 + Rfootflag) * walktime_n;
			Footpos[i] = Sinusoidal(t_rel, walktime_n *0.3, 2*step) + (2 * Rfootflag - 1) * step;
		}
		
		else if (i < (Rfootflag + 1.1) * dwalktime_n) Footpos[i] = (2 * Rfootflag + 1) * step;
		else Footpos[i] = (2 * step_n - 3) * step;

		if ((i + 1) % walktime_n == 0)
		{
			if (Rfootflag < step_n - 2) Rfootflag = Rfootflag + 1;
		}
	};
	return Footpos;
};

MatrixXd Trajectory::LF_xsimulation_straightwalk()
{
	int sim_n = step_n * walktime_n;
	double dwalktime_n = walktime_n;
	double Lfootflag = 0;

	RowVectorXd Footpos(sim_n);
	Footpos.setZero();

	for (int i = 0; i < sim_n; i++)
	{
		if (i < 1.1 * walktime_n) Footpos[i] = 0;
		else if (i < (Lfootflag + 0.1) * walktime_n) Footpos[i] = (2 * Lfootflag - 2) * step;
		else if (i < (Lfootflag + 0.4) * walktime_n){
			double t_rel = i - (Lfootflag + 0.1) * dwalktime_n;
			Footpos[i] = Sinusoidal(t_rel, walktime_n * 0.3, 2* step) + (2 * Lfootflag - 2) * step;
		}

		else if (i < (Lfootflag + 1.1) * walktime_n) Footpos[i] = (2 * Lfootflag) * step;

		else if (i < (step_n - 0.6) * walktime_n) {
			double t_rel = i - (Lfootflag + 1.1) * dwalktime_n;
			Footpos[i] = Sinusoidal(t_rel, walktime_n * 0.3, step) + (2 * step_n - 4) * step;
		}

		else Footpos[i] = (2 * step_n - 3) * step;

		if ((i + 1) % walktime_n == 0)
		{
			if (Lfootflag < step_n - 2) Lfootflag = Lfootflag + 1;
		}
	};
	return Footpos;
}

MatrixXd Trajectory::RF_zsimulation_straightwalk(double h) 
{
    int sim_n = step_n * walktime_n;
	double dwalktime_n = walktime_n;
    double Rfootflag = 0;

    RowVectorXd Footpos(sim_n);
    Footpos.setZero();

    for (int i = 0; i < sim_n; i++) {
        double rise_start = (Rfootflag + 0.55) * dwalktime_n;
        double rise_end   = (Rfootflag + 0.75) * dwalktime_n;
        double fall_end   = (Rfootflag + 0.95) * dwalktime_n;

		double T = 0.2 * dwalktime_n;

		if (i < rise_start) Footpos[i] = 0;

        else if (i >= rise_start && i < rise_end) {
            double phase_time = i - rise_start;
            Footpos[i] = Sinusoidal(phase_time, T, h);  // 올림
        }
        else if (i >= rise_end && i < fall_end) {
            double phase_time = fall_end - i;
            Footpos[i] = Sinusoidal(phase_time, T, h);  // 내림
        }
		else if (i  < (Rfootflag + 1) * dwalktime_n) Footpos[i] = 0;
		else Footpos[i] = 0;

        if ((i + 1) % walktime_n == 0) {
            if (Rfootflag < step_n - 2) Rfootflag += 1;
        }
    }

    return Footpos;
}

MatrixXd Trajectory::LF_zsimulation_straightwalk(double h) {
    int sim_n = step_n * walktime_n;
	double dwalktime_n = walktime_n;
    double Lfootflag = 0;

    RowVectorXd Footpos(sim_n);
    Footpos.setZero();

    for (int i = 0; i < sim_n; i++) {
		double rise_start = (Lfootflag + 0.05) * dwalktime_n;
		double rise_end   = (Lfootflag + 0.25) * dwalktime_n;
		double fall_end   = (Lfootflag + 0.45) * dwalktime_n;

		double T = 0.2 * dwalktime_n;  // cos traj. 

		if (i < 1.05 * dwalktime_n) Footpos[i] = 0;

        else if (i >= rise_start && i < rise_end) {
            double phase_time = i - rise_start;
            Footpos[i] = Sinusoidal(phase_time, T, h);  // 올림
        }
        else if (i >= rise_end && i < fall_end) {
            double phase_time = fall_end - i;
            Footpos[i] = Sinusoidal(phase_time, T, h);  // 내림
        }
		else if (i < (Lfootflag + 0.5) * dwalktime_n) Footpos[i] = 0;

		else Footpos[i] = 0;

        if ((i + 1) % walktime_n == 0) {
            if (Lfootflag < step_n - 1) Lfootflag += 1;
        }
    }

    return Footpos;
}


void Trajectory::InitROS(const rclcpp::Node::SharedPtr& node) {
    auto qos = rclcpp::QoS(1).reliable().transient_local(); // 최신 1개 보존
    vy_world_sub = node->create_subscription<std_msgs::msg::Float32>(
        "/act_com_y_vel", qos,
        [this](const std_msgs::msg::Float32::SharedPtr m){
            this->UpdateIMUYVel(static_cast<double>(m->data)); // ② 주기 갱신
        });
}


void Trajectory::Go_Straight(double step, double distance, double height)
{
    Set_step(step);
    Set_distance(distance, 0.06);
    Xcom = XComSimulation();
    Ycom = YComSimulation();
    LF_xFoot = LF_xsimulation_straightwalk();
    RF_xFoot = RF_xsimulation_straightwalk();

    // CP 시퀀스가 비어있으면 현재 IMU 기반 Δy로 채워서 테스트 가능
    if (dy_cp_seq_.empty()) {
        ReserveCPSeq();
        const double dy_current = CPdy();
        for (int k = 0; k < (int)dy_cp_seq_.size(); ++k) dy_cp_seq_[k] = dy_current;
    }
    RF_yFoot = BuildRF_y_with_CP(L0);
    LF_yFoot = BuildLF_y_with_CP(L0);

    Ref_RL_x = RF_xFoot - Xcom;
    Ref_LL_x = LF_xFoot - Xcom;
    Ref_RL_y = RF_yFoot - Ycom;
    Ref_LL_y = LF_yFoot - Ycom;
    Ref_RL_z = RF_zsimulation_straightwalk(height);
    Ref_LL_z = LF_zsimulation_straightwalk(height);
}

void Trajectory::Go_Straight_start(double step, double distance, double height)
{
    Set_step(step);
    Set_distance_start(distance);
    Xcom = XComSimulation();
    Ycom = YComSimulation();
    LF_xFoot = LF_xsimulation_straightwalk();
    RF_xFoot = RF_xsimulation_straightwalk();

    if (dy_cp_seq_.empty()) {
        ReserveCPSeq();
        const double dy_current = CPdy();
        for (int k = 0; k < (int)dy_cp_seq_.size(); ++k) dy_cp_seq_[k] = dy_current;
    }
    RF_yFoot = BuildRF_y_with_CP(L0);
    LF_yFoot = BuildLF_y_with_CP(L0);

    Ref_RL_x = RF_xFoot - Xcom;
    Ref_LL_x = LF_xFoot - Xcom;
    Ref_RL_y = RF_yFoot - Ycom;
    Ref_LL_y = LF_yFoot - Ycom;
    Ref_RL_z = RF_zsimulation_straightwalk(height);
    Ref_LL_z = LF_zsimulation_straightwalk(height);
}
