#include "DynamicsController.hpp"

DynamicsController::DynamicsController( double control_frequency, SharedMemory* shared_memory):
    control_frequency_(control_frequency),
    shared_memory_(shared_memory),
    PS_(new PostureStablizer()),
    BodyVelocity(18,3,24), DoB( 12,12,6), tcp_server_(9000)
    {
        if (!tcp_server_.start()) {
            std::cerr << "TCP 서버 시작 실패 (port=9000)" << std::endl;
        }   
    }
DynamicsController::~DynamicsController()
{
    delete PS_;
}

void DynamicsController::Initialize()
{   
    // RBDL 초기화
    RBDL_.Init_RBDL();
    InitKalmanBV();
    InitKalmanDOB();
    robot_config_ = loadConfig("../config/WBC_config.yaml");
}
void DynamicsController::InitKalmanBV()
{   
    Eigen::VectorXd Initial_X(18);
    Initial_X << 0, 				0, 				(-foot_pos(2,0) -foot_pos(2,1) -foot_pos(2, 2) -foot_pos(2, 3))/4, 
                 0, 				0, 				0, 
                 ROBOT_WIDTH/2, 	ROBOT_PSIDE/2, 	0,         
                 ROBOT_WIDTH/2,    -ROBOT_PSIDE/2,	0,     	
                -ROBOT_WIDTH/2,	    ROBOT_PSIDE/2, 	0,     
                -ROBOT_WIDTH/2,    -ROBOT_PSIDE/2,  0; 
    BodyVelocity.setx0(Initial_X);

    std::array<double,6> diagP = {100, 100, 0.001, 0.001, 0.001, 0.001};
    Eigen::MatrixXd Initial_P = Eigen::MatrixXd::Zero(18, 18);
    for (int i = 0; i < 6; ++i)Initial_P.block<3,3>(3*i, 3*i) = I3 * diagP[i];
    BodyVelocity.setP0(Initial_P);
    
    std::array<double,6> diagQ = {std::pow(0.001,2),std::pow(0.001,1),std::pow(0.001,2),std::pow(0.001,2),std::pow(0.001,2),std::pow(0.001,2)};
    Eigen::MatrixXd Initial_Q = Eigen::MatrixXd::Zero(18, 18);
    for (int i = 0; i < 6; ++i)Initial_Q.block<3,3>(3*i, 3*i) = I3 * diagQ[i];
    BodyVelocity.setQ(Initial_Q);

    double o_noise1=0.000002;	        double o_noise2=0.02;
    std::array<double,8> diagR = { o_noise1, o_noise1, o_noise1, o_noise1, o_noise2, o_noise2, o_noise2, o_noise2 };
    Eigen::MatrixXd Initial_R = Eigen::MatrixXd::Zero(24, 24);
    for (int i = 0; i < 8; ++i) {
        Initial_R.block<3,3>(3*i, 3*i) = I3 * diagR[i] * 0.49;
    }
    BodyVelocity.setR(Initial_R);    
    
}
void DynamicsController::InitKalmanDOB()
{   
    SRB_model_.stateDim = 12;            
    SRB_model_.inputDim = 12;            
    SRB_model_.outputDim = 6;

    Eigen::MatrixXd A = Eigen::MatrixXd::Zero(SRB_model_.stateDim, SRB_model_.stateDim);
    A.block<3, 3>(0, 0) = I3;
    A.block<3, 3>(3, 3) = I3;
    A.block<3, 3>(0, 6) = (dt / ROBOT_M) * I3;
    
    // M_KDB는 시변이므로 inverse는 루프에서 직접 계산
    Eigen::Matrix3d M_KDB =I3;
    A.block<3, 3>(3, 9) = dt * M_KDB.inverse();  
    A.block<3, 3>(6, 6) = I3;
    A.block<3, 3>(9, 9) = I3;
    DoB.setA( A );

    Eigen::MatrixXd B = Eigen::MatrixXd::Zero(SRB_model_.stateDim, SRB_model_.inputDim);
    Eigen::MatrixXd W_b = Eigen::MatrixXd::Identity(12, 12); // 입력 신뢰도 가중치 행렬
    for (int i = 0; i < 4; ++i)
    {
        double trust = (Pattern_.SW_FLAG[i] == 0) ? 1.0 : 0.01;  // 스탠스: 1.0, 스윙: 0.01
        B.block<3, 3>(0, i * 3) = (dt / ROBOT_M) * I3;
        Eigen::Vector3d r_i = foot_pos.col(i);
        Eigen::Matrix3d skew_r_i;
        skew_r_i <<      0, -r_i(2),  r_i(1),
                    r_i(2),      0, -r_i(0),
                   -r_i(1),  r_i(0),      0;
        B.block<3, 3>(3, i * 3) = -dt * skew_r_i;
        W_b.block<3,3>(i*3, i*3) *= trust;
    }
    DoB.setB( B* W_b);  // 신뢰도 가중치 반영된 B

    // C, Q, R 초기화
    Eigen::MatrixXd C = Eigen::MatrixXd::Zero(SRB_model_.outputDim, SRB_model_.stateDim);
    C.block<3, 3>(0, 6) = (1.0 / ROBOT_M) * I3; 
    C.block<3, 3>(3, 3) = I3;
    C.block<3, 3>(3, 9) = I3;
    DoB.setC( C );

    Eigen::MatrixXd Q = Eigen::MatrixXd::Identity(SRB_model_.stateDim, SRB_model_.stateDim);
    Q.block<3,3>(0,0)   = I3 * 1e-3; // v_com
    Q.block<3,3>(3,3)   = I3 * 1e-4; // w_com
    Q.block<3,3>(6,6)   = I3 * 1e-2; // F_ext
    Q.block<3,3>(9,9)   = I3 * 1e-1; // tau_ext
    DoB.setQ( Q );

    Eigen::MatrixXd R = Eigen::MatrixXd::Identity(SRB_model_.outputDim, SRB_model_.outputDim);// * pow(0.001, 5);
    R.block<3,3>(0,0) = I3 * pow(0.001, 3); // 1e-3; // a_imu
    R.block<3,3>(3,3) = I3 * pow(0.001, 3); // 1e-4; // w_imu
    DoB.setR( R );

    Eigen::VectorXd x_hat = Eigen::VectorXd::Zero(SRB_model_.stateDim);
    DoB.setx0( x_hat );

    Eigen::MatrixXd P = Eigen::MatrixXd::Identity(SRB_model_.stateDim, SRB_model_.stateDim) * 1.0;
    DoB.setP0( P );

   
}

void DynamicsController::MainLoop()
{

    PreProcessing();

    MidProcessing();

    PostProcessing();

}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void DynamicsController::PreProcessing()
{
    ct++;
    Looptime_ =  ct/ control_frequency_; 
    Euler = Quat2EulerClamped(shared_memory_->quat);
    R_Mtrx = Quat2RotMatrix(shared_memory_->quat);
    R_Mtrx_Trs = R_Mtrx.transpose();
    q_  =ReMapLegOrder(shared_memory_->q);
    dq_ =ReMapLegOrder(shared_memory_->qd);
    IMU_angvel = Eigen::Vector3d(shared_memory_->IMU[0], shared_memory_->IMU[1], shared_memory_->IMU[2]);
    IMU_linacc = Eigen::Vector3d(shared_memory_->IMU[3], shared_memory_->IMU[4], shared_memory_->IMU[5]);
    SetQState(q_);
    SetDQState(dq_);
    GetKinematics();
    GetJacobian();
    GetDynamics();
}
    void DynamicsController::SetQState(Eigen::VectorXd& q_vec) {
        q_state << Zero6, q_vec;
    }
    void DynamicsController::SetDQState(Eigen::VectorXd& dq_vec){
        dq_state << Zero6, dq_vec;
    }
    Eigen::Matrix3d DynamicsController::Quat2RotMatrix(std::vector<double>& quat)
    {
        Eigen::Quaterniond q(quat[0], quat[1], quat[2], quat[3]);
        double yaw = std::atan2(
            2.0 * (q.w()*q.z() + q.x()*q.y()),
            1.0 - 2.0 * (q.y()*q.y() + q.z()*q.z())
        );
        Eigen::Quaterniond q_yaw(Eigen::AngleAxisd(yaw, Eigen::Vector3d::UnitZ()));
        Eigen::Quaterniond q_rp = q_yaw.inverse() * q;
        return q_rp.toRotationMatrix();
    }
    Eigen::Vector3d DynamicsController::Quat2EulerClamped(const std::vector<double>& quat) {
        // Eigen quaternion 은 w,x,y,z 순
        Eigen::Quaterniond q(quat[0], quat[1], quat[2], quat[3]);

        // ── 1) Roll (x-axis rotation) ─────────────────────────────────────
        double sinr_cosp = 2.0 * (q.w()*q.x() + q.y()*q.z());
        double cosr_cosp = 1.0 - 2.0 * (q.x()*q.x() + q.y()*q.y());
        double roll = std::atan2(sinr_cosp, cosr_cosp);  // (–π, +π]

        // ── 2) Pitch (y-axis rotation) ────────────────────────────────────
        double sinp = 2.0 * (q.w()*q.y() - q.z()*q.x());
        // asin 입력값이 [-1,1] 넘어가면 NaN 되기 때문에 clamp 처리
        sinp = std::clamp(sinp, -1.0, 1.0);
        double pitch = std::asin(sinp);                    // [–π/2, +π/2]

        // ── 3) Yaw (z-axis rotation) ──────────────────────────────────────
        double siny_cosp = 2.0 * (q.w()*q.z() + q.x()*q.y());
        double cosy_cosp = 1.0 - 2.0 * (q.y()*q.y() + q.z()*q.z());
        double yaw = std::atan2(siny_cosp, cosy_cosp);    // (–π, +π]

        return { roll, pitch, yaw };
    }
    void DynamicsController::GetKinematics(){
        for (int leg = 0; leg < 4; leg++){
            Kine_.legFK(q_[3*leg+0],q_[3*leg+1],q_[3*leg+2], leg, LEG_0, LEG_1, LEG_2, ROBOT_WIDTH, ROBOT_PSIDE, R_Mtrx, foot_pos);
        }
        foot_vel.col(0) = J_.FL.J * dq_.segment<3>(0);
        foot_vel.col(1) = J_.FR.J * dq_.segment<3>(3);
        foot_vel.col(2) = J_.RL.J * dq_.segment<3>(6);
        foot_vel.col(3) = J_.RR.J * dq_.segment<3>(9);
    }
    void DynamicsController::GetJacobian(){
        J_.FL.J     = RBDL_.CalcFootJacobian(_FL_, q_state);
        J_.FL.J_Trs = J_.FL.J.transpose();
        J_.FR.J     = RBDL_.CalcFootJacobian(_FR_, q_state);
        J_.FR.J_Trs = J_.FR.J.transpose();
        J_.RL.J     = RBDL_.CalcFootJacobian(_RL_, q_state);
        J_.RL.J_Trs = J_.RL.J.transpose();
        J_.RR.J     = RBDL_.CalcFootJacobian(_RR_, q_state);
        J_.RR.J_Trs = J_.RR.J.transpose();
        
        J_.Body.Whole = RBDL_.CalcWholeJacobian(q_state);
        J_.Body.Whole_Trs.block(6,6,12,12) = RBDL_.CalcWholeJacobianTrans(J_.Body.Whole);
        J_.Body.Whole_Trs.block(0,0,6,6) = Eigen::MatrixXd::Identity(6, 6);

        J_.LEGs.block(0,0, 3, 3) = J_.FL.J;
        J_.LEGs.block(3,3, 3, 3) = J_.FR.J;
        J_.LEGs.block(6,6, 3, 3) = J_.RL.J;
        J_.LEGs.block(9,9, 3, 3) = J_.RR.J;

        RBDL_.CalcJacobianDot(LEG_0, LEG_1, LEG_2, q_(0), q_(1),    q_(2),  dq_(0), dq_(1),     dq_(2),     _FL_, J_.FL.J_dot );
        RBDL_.CalcJacobianDot(LEG_0, LEG_1, LEG_2, q_(3), q_(4),    q_(5),  dq_(3), dq_(4),     dq_(5),     _FR_, J_.FR.J_dot );
        RBDL_.CalcJacobianDot(LEG_0, LEG_1, LEG_2, q_(6), q_(7),    q_(8),  dq_(6), dq_(7),     dq_(8),     _RL_, J_.RL.J_dot );
        RBDL_.CalcJacobianDot(LEG_0, LEG_1, LEG_2, q_(9), q_(10),   q_(11), dq_(9), dq_(10),    dq_(11),    _RR_, J_.RR.J_dot );
        
        J_.Body.Whole_Dot.block(6,6,3,3)    = J_.FL.J_dot ;
        J_.Body.Whole_Dot.block(9,9,3,3)    = J_.FR.J_dot ;
        J_.Body.Whole_Dot.block(12,12,3,3)  = J_.RL.J_dot ;
        J_.Body.Whole_Dot.block(15,15,3,3)  = J_.RR.J_dot ;
    }
    void DynamicsController::GetDynamics(){
        Dyn_.M_.Body    = RBDL_.GetBodyInertiaMatrix(q_state);
        Dyn_.M_.Leg     = RBDL_.GetLegInertiaMatrix(q_state);
        Dyn_.M_.FL_.M3  = Dyn_.M_.Leg.block(0, 6, 3, 3);
        Dyn_.M_.FR_.M3  = Dyn_.M_.Leg.block(3, 9, 3, 3);
        Dyn_.M_.RL_.M3  = Dyn_.M_.Leg.block(6, 12, 3, 3);
        Dyn_.M_.RR_.M3  = Dyn_.M_.Leg.block(9, 15, 3, 3);

        Dyn_.CG_.Body    = RBDL_.GetBodyColiolisAndGravityVector(q_state, dq_state);
        Dyn_.CG_.Leg     = RBDL_.GetLegColiolisAndGravityVector(q_state, dq_state);
        Dyn_.CG_.FL_.CG3 = Dyn_.CG_.Leg.segment<3>(0);
        Dyn_.CG_.FR_.CG3 = Dyn_.CG_.Leg.segment<3>(3);
        Dyn_.CG_.RL_.CG3 = Dyn_.CG_.Leg.segment<3>(6);
        Dyn_.CG_.RR_.CG3 = Dyn_.CG_.Leg.segment<3>(9);  

        Dyn_.M_.BodyInertiaRotation = Dyn_.M_.Body.block(3, 3, 3, 3);
    }

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void DynamicsController::StandUpMotion(double now)
{
    // 1) 이미 완료되었으면 아무것도 하지 않음
    if (StandUp.finished) 
    {
        return;
    }

    // 2) 시작 시점 초기화
    if (!StandUp.started) {
        StandUp.started    = true;
        StandUp.startTime  = now;
        StandUp.InitPose   = q_;   // 현재 관절각 저장
        StandUp.InitVel    = dq_;  // 현재 관절속도 저장
        StandUp.RefPose    << 0.0, 0.8, -1.6, 0.0, 0.8, -1.6, 0.0, 0.8, -1.6, 0.0, 0.8, -1.6 ;
    }
    // 3) 경과 시간 및 τ 계산
    double t    = now - StandUp.startTime;
    double tau  = std::clamp(t / StandUp.duration, 0.0, 1.0);

    double s   = GC_.quintic(tau);
    double ds  = GC_.dquintic(tau) / StandUp.duration;  // dτ/dt = 1/duration

    // 4) 목표 각도 & 속도
    Eigen::VectorXd poserr  = StandUp.RefPose - StandUp.InitPose;
    Eigen::VectorXd q_ref   = StandUp.InitPose + poserr * s;
    Eigen::VectorXd dq_ref  = poserr * ds;
    Eigen::VectorXd tau_all = StandUp.Kp.cwiseProduct(q_ref  - q_) + StandUp.Kd.cwiseProduct(dq_ref - dq_);
    
    // 6) 다리별로 Dyn_.Torque에 할당
    for(int leg = 0; leg < 4; ++leg) {
        Eigen::Vector3d tau3 = tau_all.segment<3>(3*leg);
        switch(leg) {
            case _FL_: Dyn_.Torque.FL_.Leg = tau3; break;
            case _FR_: Dyn_.Torque.FR_.Leg = tau3; break;
            case _RL_: Dyn_.Torque.RL_.Leg = tau3; break;
            case _RR_: Dyn_.Torque.RR_.Leg = tau3; break;
        }
    }

    // 7) 완료 플래그
    if (tau >= 1.0) {
        StandUp.finished = true;
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void DynamicsController::MidProcessing()
{
    StateEstimator();
    
    if (StandUp.finished)
    {
        int gait_mode = 3;
        
        if (Looptime_ > 5.0) {
            // gait_mode = 4;
            Walking_FLAG = true;
            // KickMode(0); // 앞다리 킥 모드
        }
        GaitSelector( Walking_FLAG, gait_mode);
        SwingLegController();
        QPController();
    }
    else{
        StandUpMotion(Looptime_);
    }

}
    void DynamicsController::StateEstimator()
    {

        SetReferencePosture();

        // --- 1) 발 위치/속도 계산 ---
        Act.FL_.pos = foot_pos.col(_FL_);
        Act.FL_.vel = foot_vel.col(_FL_);

        Act.FR_.pos = foot_pos.col(_FR_);
        Act.FR_.vel = foot_vel.col(_FR_);

        Act.RL_.pos = foot_pos.col(_RL_);      
        Act.RL_.vel = foot_vel.col(_RL_);

        Act.RR_.pos = foot_pos.col(_RR_);
        Act.RR_.vel = foot_vel.col(_RR_);


        // --- 2) CoM 위치/속도 추정 ---
        Eigen::Vector3d CoMVel = Eigen::Vector3d::Zero();
        CoMVel = CalcKalmanBV();

        // X
        Act.CoM_.pos(0) = -(Act.FL_.pos(0) + Act.FR_.pos(0) + Act.RL_.pos(0) + Act.RR_.pos(0)) / 4.0;
        Act.CoM_.vel(0) = GC_.LowPassFilter(-CoMVel(0), Act.CoM_.vel(0), SensorLPFHz, dt);
        // Y
        Act.CoM_.pos(1) = -(Act.FL_.pos(1) + Act.FR_.pos(1) + Act.RL_.pos(1) + Act.RR_.pos(1)) / 4.0;
        Act.CoM_.vel(1) = GC_.LowPassFilter(-CoMVel(1), Act.CoM_.vel(1), SensorLPFHz, dt);

        // Z
        Act.CoM_.pos(2) = Kine_.tempKinematicHeight(foot_pos, 2, dt);
        Act.CoM_.vel(2) = (Act.CoM_.pos(2) - old_z) / dt;      
        old_z = Act.CoM_.pos(2);

        // Roll
        Act.CoM_.pos(3) = Euler(0);
        Act.CoM_.vel(3) = shared_memory_->gyro[0];

        // Pitch
        Act.CoM_.pos(4) = Euler(1);
        Act.CoM_.vel(4) = shared_memory_->gyro[1];

        // Yaw
        Act.CoM_.pos(5) = Euler(2);
        Act.CoM_.vel(5) = shared_memory_->gyro[2];

        // - - - 경사 추정 - - - //


        // - - - 미끄러짐 추정 - - - //
        slip_Prob = CalcSlipProb(Pattern_.SW_FLAG, foot_vel);
        // - - - 착지 힘 추정 - - - //


        // - - - 외란 추정 - - - //
        Eigen::VectorXd CoMdistForce = Eigen::VectorXd::Zero(12);
        CoMdistForce = CalcKalmanDoB();
        Disturbance = CoMdistForce.segment<6>(6); // 외란 힘

        // - - - 위험도 추정 - - - //
        for (int i = 0; i < 4; ++i) {
            Risk_.slip_prob[i] = slip_Prob[i];
        }
        Risk_.DistForce = Disturbance.segment<3>(0); 
        Risk_.DistMoment = Disturbance.segment<3>(3); 
        Risk_.imu_rpy_ = Euler;
        Risk_.desired_theta_R =Ref.CoM_.pos(3); // 목표 롤 각도
        Risk_.desired_theta_P =Ref.CoM_.pos(4); // 목표 피치
        Risk_.FLAG = RE_.RiskBaseDecisionMaker(Risk_.slip_prob, Risk_.DistForce, Risk_.DistMoment, Risk_.imu_rpy_, Risk_.desired_theta_R, Risk_.desired_theta_P);
        if (Risk_.FLAG == 1) {
            shared_memory_->LED = true; // 위험 상태
        }
    }
        Eigen::Vector3d DynamicsController::CalcKalmanBV()
        {
            Eigen::Matrix<double,18,18> A = Eigen::Matrix<double,18,18>::Identity();
            A.block<3,3>(0, 3) = I3 * dt;
            BodyVelocity.setA(A);

            Eigen::Matrix<double,18,3> B =Eigen::Matrix<double,18,3>::Zero();
            B << I3*(dt*dt/2), I3*dt, Z3, Z3, Z3, Z3;                 
            BodyVelocity.setB(B);

            Eigen::Matrix<double,24,18> C = Eigen::Matrix<double,24,18>::Zero();
            for (int i = 0; i < 4; ++i) {
                C.block<3,3>(3*i, 3*0) = -I3;
                C.block<3,3>(3*i, 3*(2 + i)) = I3;
                C.block<3,3>(3*(4 + i), 3*1) = -I3;
            }
            BodyVelocity.setC(C);

            Eigen::Matrix<double,24,1> z = Eigen::Matrix<double,24,1>::Zero();
            for (int i = 0; i < 4; ++i) {
                z.segment<3>(3*i) = -foot_pos.col(i);
                z.segment<3>(12 + 3*i) = -foot_vel.col(i);
            }
            
            Eigen::Vector3d u = Eigen::Vector3d::Zero();
            if (Walking_FLAG == true) {
                u(0) = IMU_linacc[0]; 
                u(1) = IMU_linacc[1];
                u(2) = IMU_linacc[2] - Gravity; // Z축 가속도
            }
            else {
                u(0) = 0; 
                u(1) = 0;
                u(2) = shared_memory_->IMU[5] - Gravity; 
            }
            
            Eigen::Matrix<double,24,24> R = Eigen::Matrix<double,24,24>::Zero();
            double o_noise1=0.000002;	        double o_noise2=0.02;
            std::array<double,4> o_scale = {0.49, 0.49, 0.49, 0.49};
            if (Walking_FLAG) {
                for (int i = 0; i < 4; ++i) {
                    // Pattern_.SW_FLAG[i] == 1 → 80 + dt, 0 → dt
                    o_scale[i] = -1 * ( -80.0 * Pattern_.SW_FLAG[i] - dt );
                }
            }
            for (int i = 0; i < 4; ++i) {
                R.block<3,3>(3*i,     3*i    ) = I3 * (o_noise1 * o_scale[i]);
                R.block<3,3>(3*(4+i), 3*(4+i)) = I3 * (o_noise2 * o_scale[i]);
            }
            BodyVelocity.setR(R);   

            BodyVelocity.predict(u);
            BodyVelocity.update(z);
            Eigen::VectorXd x_est = BodyVelocity.getState();
            // Eigen::VectorXd x_est = Eigen::VectorXd::Zero(18);
            return x_est.segment(3, 3);
        }
        Eigen::VectorXd DynamicsController::CalcKalmanDoB()
        {
            Eigen::MatrixXd A = Eigen::MatrixXd::Zero(SRB_model_.stateDim, SRB_model_.stateDim);
            A.block<3, 3>(0, 0) = I3;
            A.block<3, 3>(3, 3) = I3;
            A.block<3, 3>(0, 6) = (dt / ROBOT_M) * I3;
            A.block<3, 3>(3, 9) = dt * Dyn_.M_.BodyInertiaRotation.inverse();  
            A.block<3, 3>(6, 6) = I3;
            A.block<3, 3>(9, 9) = I3;
            DoB.setA(A);
            Eigen::MatrixXd B = Eigen::MatrixXd::Zero(SRB_model_.stateDim, SRB_model_.inputDim);
            Eigen::MatrixXd W_b = Eigen::MatrixXd::Identity(12, 12); 
            for (int i = 0; i < 4; ++i)
            {
                double trust = (Pattern_.SW_FLAG[i] == 0) ? 1.0 : 0.01; 
                B.block<3, 3>(0, i * 3) = (dt / ROBOT_M) * I3;
                Eigen::Vector3d r_i = foot_pos.col(i);
                Eigen::Matrix3d skew_r_i;
                skew_r_i <<      0, -r_i(2),  r_i(1),
                            r_i(2),       0, -r_i(0),
                           -r_i(1),  r_i(0),       0;
                // B.block<3, 3>(3, i * 3) = -dt * skew_r_i;
                B.block<3, 3>(9, i * 3) = -dt * skew_r_i;
                W_b.block<3,3>(i*3, i*3) *= trust;
            }
            DoB.setB(B* W_b);

            Eigen::VectorXd u = Eigen::VectorXd::Zero(SRB_model_.inputDim);
            u.segment<3>(0) = Dyn_.Force.FL_.QPLambda;
            u.segment<3>(3) = Dyn_.Force.FR_.QPLambda;
            u.segment<3>(6) = Dyn_.Force.RL_.QPLambda;
            u.segment<3>(9) = Dyn_.Force.RR_.QPLambda;
            Eigen::VectorXd u_scaled = u;
            for (int i = 0; i < 4; ++i) {
                double trust = (Pattern_.SW_FLAG[i] == 0) ? 1.0 : 0.01;
                u_scaled.segment<3>(i*3) *= trust;
            }

            Eigen::VectorXd y = Eigen::VectorXd::Zero(SRB_model_.outputDim);
            y.segment<3>(0) = IMU_linacc;      
            y.segment<3>(3) = IMU_angvel;   
            DoB.predict(u_scaled);
            DoB.update(y);

            return DoB.getState();
        }
        Eigen::Vector4d DynamicsController::CalcSlipProb( bool SW[4], Eigen::MatrixXd& FV)
        {
            std::array<bool,4>              SW_Flag_SD; 
            std::array<Eigen::Vector3d,4>   footVel_SD;
            Eigen::Vector4d SlipProb = Eigen::Vector4d::Zero();
            for(int leg=0; leg<4; ++leg){
                SW_Flag_SD[leg] = !SW[leg];
                footVel_SD[leg] = FV.col(leg);
                if (SW_Flag_SD[leg]) {
                    SD_.updateLeg(leg, SW_Flag_SD[leg], footVel_SD[leg]);
                    if (SD_.isSlip(leg)) {
                        // std::cout << "[Warning] Leg " << leg << " slip! belief=" << SD_.getBelief(leg) << std::endl;
                    }
                }
                SlipProb[leg] = SD_.getBelief(leg); 
            }
            return SlipProb;
        }       
        void DynamicsController::SetReferencePosture()
        {
            Ref.CoM_.pos(0) = 0;
            Ref.CoM_.pos(1) = 0;
            Ref.CoM_.pos(2) = ROBOT_STAND_HEIGHT; 

            Ref.CoM_.pos(3) = 0; // Roll
            Ref.CoM_.pos(4) = 0; // Pitch
            Ref.CoM_.pos(5) = 0; // Yaw
    
            Ref.CoM_.vel(0) = shared_memory_->lin_vel_target[0] *0.8;
            Ref.CoM_.vel(1) = shared_memory_->lin_vel_target[1] *0.8;
            Ref.CoM_.vel(2) = 0;

            Ref.CoM_.vel(3) = 0; // Roll
            Ref.CoM_.vel(4) = 0; // Pitch
            Ref.CoM_.vel(5) =  shared_memory_->ang_vel_target[2] *1; // Yaw
        }
    void DynamicsController::GaitSelector( bool WALKING_FLAG_, int Gait)
    {
        // --- 1) 시간 업데이트 ---
        Pattern_.ct++;
        Pattern_.time = Pattern_.ct / Pattern_.hz;

        // --- 2) 수동 변경 요청 감지 (즉시 new_cycle 은 트리거하지 않음) ---
        if (WALKING_FLAG_  != Pattern_.prev_walking_flag || Gait != Pattern_.prev_gait_mode)
        {
            Pattern_.req_walking_flag = WALKING_FLAG_;
            Pattern_.req_gait_mode    = Gait;
        }

        // --- 3) 새 사이클 시작 판별: 첫 사이클 or 사이클 만료(=timeout) 일 때만 ---
        bool timeout   = (Pattern_.time >= Pattern_.cycle_start_time + Pattern_.cycle_length);
        bool new_cycle = Pattern_.first_cycle || timeout;

        if (new_cycle) {
            // --- 3.1) 사이클 경계 진입 시 요청이 있으면 prev 에 반영 ---
            if (Pattern_.first_cycle) {
            } 
            else if (Pattern_.req_gait_mode != Pattern_.prev_gait_mode || Pattern_.req_walking_flag != Pattern_.prev_walking_flag)
            {
                Pattern_.prev_gait_mode    = Pattern_.req_gait_mode;
                Pattern_.prev_walking_flag = Pattern_.req_walking_flag;
            }

            // --- 3.2) 사이클 초기화 ---
            Pattern_.cycle_start_time = Pattern_.time;
            Pattern_.first_cycle      = false;

            bool walking = Pattern_.prev_walking_flag;
            int  gait    = Pattern_.prev_gait_mode;

            if (!walking) {
                // 보행 OFF: 다음 사이클부터 완전 스탠스
                Pattern_.cycle_length = 0.0;
                Pattern_.time_sw      = 0.0;
                Pattern_.time_st      = 0.0;
            }
            else {
                // 페이즈 설정 (TROT=1, WALK=2)
                switch (gait) {
                    case 1:
                        Pattern_.cycle_length = Trot_Cycle_Length;
                        Pattern_.time_sw      = (Pattern_.cycle_length / 2.0) * 0.9;
                        break;
                    case 2:
                        Pattern_.cycle_length = Walk_Cycle_Length;
                        Pattern_.time_sw      = (Pattern_.cycle_length / 4.0) * 0.9;
                        break;
                    case 3:
                        Pattern_.cycle_length = FastTrot_Cycle_Length;
                        Pattern_.time_sw      = (Pattern_.cycle_length / 2.0) * 0.9;
                        break;
                    case 4:
                        Pattern_.cycle_length = FlyingTrot_Cycle_Length;
                        Pattern_.time_sw      = (Pattern_.cycle_length / 2.0) * 1.3;
                        break;
                    default:
                        Pattern_.cycle_length = 0.0;
                        Pattern_.time_sw      = 0.0;
                }
                Pattern_.time_st = Pattern_.cycle_length - Pattern_.time_sw;
            }

            // --- 3.3) Swing 플래그 & 타이밍 재설정 ---
            for (int leg = 0; leg < 4; ++leg) {
                Pattern_.SW_FLAG[leg] = DOWN;
            }
            if (walking) {
                const double* pattern = (gait == 2)
                    ? Pattern_.walk_pattern_ratio
                    : Pattern_.trot_pattern_ratio;
                for (int leg = 0; leg < 4; ++leg) {
                    double up = pattern[leg] * Pattern_.cycle_length;
                    Pattern_.Sw_timing[UP][leg]   = Pattern_.cycle_start_time + up;
                    Pattern_.Sw_timing[DOWN][leg] = Pattern_.Sw_timing[UP][leg] + Pattern_.time_sw;
                }
            }
        }

        // --- 4) Swing/Stand 플래그 업데이트 (언제나 기존 페이즈 유지) ---
        for (int leg = 0; leg < 4; ++leg) {
            if (Pattern_.prev_walking_flag && Pattern_.time >= Pattern_.Sw_timing[UP][leg] && Pattern_.time <  Pattern_.Sw_timing[UP][leg] + Pattern_.time_sw && Pattern_.SW_FLAG[leg] == DOWN)
            {
                Pattern_.SW_FLAG[leg] = ON;
            }
            else if (Pattern_.SW_FLAG[leg] == ON && Pattern_.time >= Pattern_.Sw_timing[DOWN][leg])
            {
                Pattern_.SW_FLAG[leg] = DOWN;
                // 이 순간의 실제 발 위치를 저장
                Pattern_.stanceXtraj[leg] = foot_pos(_X_, leg);
                Pattern_.stanceYtraj[leg] = foot_pos(_Y_, leg);
                Pattern_.stanceZtraj[leg] = -ROBOT_STAND_HEIGHT; // Z축은 항상 로봇 높이로 고정
            }
        }

        // --- 5) Swing Phase(0→1) 업데이트 ---
        for (int leg = 0; leg < 4; ++leg) {
            if (Pattern_.SW_FLAG[leg] == ON) {
                // 스윙 시작 시간 기준으로 정규화
                double t0    = Pattern_.Sw_timing[UP][leg];
                double phase = (Pattern_.time - t0) / Pattern_.time_sw;
                // 범위 클램프
                if (phase < 0.0)   phase = 0.0;
                if (phase > 1.0)   phase = 1.0;
                Pattern_.SwingPhase[leg] = phase;
            }
            else {
                Pattern_.SwingPhase[leg] = 0.0;
            }
        }
    }
    void DynamicsController::SwingLegController()
    {
        TempXY = CalcRaibertHeuristic(Ref.CoM_.vel.segment(0,3), Act.CoM_.vel.segment(0,3), shared_memory_->ang_vel_target[2]); 
        tempY = CalcCapturePoint(-Act.CoM_.vel(1), 0.5); 
        Eigen::Vector4d baseX, baseY;
        for(int leg=0; leg<4; ++leg) {
            baseX[leg] = ((leg==_FL_ || leg==_FR_) ? 1.0 : -1.0) * (ROBOT_WIDTH  / 2.0);
            baseY[leg] = ((leg==_FL_ || leg==_RL_) ? 1.0 : -1.0) * (ROBOT_PSIDE / 2.0);
        }
        Eigen::Vector4d targetX = baseX + TempXY.row(0).transpose();
        Eigen::Vector4d targetY = baseY + TempXY.row(1).transpose() + tempY; // tempY는 Y축으로의 오프셋
        // ref_foot_pos = CalcQuinticSwingTrajectory(baseX, baseY, Pattern_.SwingPhase);
        ref_foot_pos = CalcQuinticSwingTrajectory(targetX, targetY, Pattern_.SwingPhase);
        Ref.FL_.pos = ref_foot_pos.col(_FL_);
        Ref.FR_.pos = ref_foot_pos.col(_FR_);
        Ref.RL_.pos = ref_foot_pos.col(_RL_);
        Ref.RR_.pos = ref_foot_pos.col(_RR_);
        CalcSwingForceControl(true); // false: CTC 모드가 아닌 일반 모드로 스윙 포스 계산
        // CalcSwingForceControl(false); // false: CTC 모드가 아닌 일반 모드로 스윙 포스 계산
    }
        Eigen::Matrix<double,2,4>  DynamicsController::CalcRaibertHeuristic(const Eigen::Vector3d& RefVel, const Eigen::Vector3d& ActVel, double omega_cmd) 
        {
            Eigen::Matrix<double,2,4> RaibertOffset;
            double omega0 = std::sqrt(ROBOT_STAND_HEIGHT / Gravity);
            double halfT  = Pattern_.time_st * 0.5;

            // 기본 Raibert heuristic
            double dx_lin = RefVel(0) * halfT + omega0 * (ActVel(0) - RefVel(0));
            double dy_lin = RefVel(1) * halfT + omega0 * (ActVel(1) - RefVel(1));

            // 회전 항 (cross-term)
            double alpha   = 0.5 * omega0;      // = ½√(h/g)
            double dx_rot  =  alpha * ActVel(1) * omega_cmd;   // v_y * ω
            double dy_rot  = -alpha * ActVel(0) * omega_cmd;   // -v_x * ω

            double dx = dx_lin + dx_rot;
            double dy = dy_lin + dy_rot;

            // 모든 다리에 동일하게 적용
            RaibertOffset.row(0).setConstant(dx);  // X-offset
            RaibertOffset.row(1).setConstant(dy);  // Y-offset
            return RaibertOffset;
        }
        Eigen::Vector4d DynamicsController::CalcCapturePoint(double Act_Com_y_vel, double CP_ratio)
        {
            double LPF_y_vel   = Act_Com_y_vel;
            double cp_scale = CP_ratio * std::sqrt(ROBOT_STAND_HEIGHT / Gravity);
            Eigen::Vector4d swingMask;
            for (int i = 0; i < 4; ++i) {swingMask(i) = (Pattern_.SW_FLAG[i] == 1 ? 1.0 : 0.0);}
            Eigen::Vector4d now_capturepoint = Eigen::Vector4d::Constant(LPF_y_vel);
            CP_Dist_Upper = CP_Dist_Upper.cwiseMax(now_capturepoint).cwiseProduct(swingMask);
            CP_Dist_Lower = CP_Dist_Lower.cwiseMin(now_capturepoint).cwiseProduct(swingMask);
            Eigen::Vector4d absU = CP_Dist_Upper.cwiseAbs();
            Eigen::Vector4d absL = CP_Dist_Lower.cwiseAbs();
            Eigen::Vector4d chosen = (absU.array() > absL.array()).select(CP_Dist_Upper, CP_Dist_Lower);
            Eigen::Vector4d CapturePoint = chosen * cp_scale;
            return CapturePoint;
        }
        Eigen::Matrix<double,3,4>  DynamicsController::CalcQuinticSwingTrajectory(Eigen::Vector4d& RefX,Eigen::Vector4d& RefY, double SwingPhase[4])
        {
            Eigen::Matrix<double,3,4>  swing_trajectory(3,4);

            for (int leg = 0; leg < 4; ++leg) {
                // 스탠스→스윙 전환 시 시작 위치 저장
                if (Pattern_.old_SW_FLAG[leg] == 0 && Pattern_.SW_FLAG[leg] == 1) {
                    tempXtraj[leg] = foot_pos(_X_, leg);
                    tempYtraj[leg] = foot_pos(_Y_, leg);
                    tempZtraj[leg] = foot_pos(_Z_, leg);
                }

                if (Pattern_.SW_FLAG[leg] == 1) {
                    // Normalize phase to [0,1]
                    double tau = std::clamp(SwingPhase[leg], 0.0, 1.0);

                    // Interpolate X and Y between start (temp*traj) and target (Ref*)
                    double x = tempXtraj[leg] + (RefX[leg] - tempXtraj[leg]) * GC_.quintic(tau);
                    double y = tempYtraj[leg] + (RefY[leg] - tempYtraj[leg]) * GC_.quintic(tau);

                    double z;
                    if (tau < 1.0 / 3.0) {
                        // rising phase
                        double phase = tau * 3.0;
                        z = tempZtraj[leg] + ROBOT_SWING_HEIGHT * GC_.quintic(phase);
                    } else {
                        // falling phase
                        double phase = (tau - 1.0 / 3.0) * 1.5;
                        z = tempZtraj[leg] + ROBOT_SWING_HEIGHT * (1.0 - GC_.quintic(phase));
                    }
                    swing_trajectory(0, leg) = x;
                    swing_trajectory(1, leg) = y;
                    swing_trajectory(2, leg) = z;

                    Pattern_.old_SW_FLAG[leg] = Pattern_.SW_FLAG[leg];

                }
               
                else if (Pattern_.SW_FLAG[leg] == 0) {
                    swing_trajectory(0, leg) = Pattern_.stanceXtraj[leg];
                    swing_trajectory(1, leg) = Pattern_.stanceYtraj[leg];
                    swing_trajectory(2, leg) = Pattern_.stanceZtraj[leg];
                    Pattern_.old_SW_FLAG[leg] = 0;
                    continue;
                }
            }
            return swing_trajectory;
        }
        void DynamicsController::CalcSwingForceControl(bool mode)
        {
            if( mode ==true ){
                Dyn_.Torque.FL_.SwingTorque = CalcTaskSpaceCTC(Ref.FL_.pos, Ref.FL_.vel, Ref.FL_.acc, Act.FL_.pos, Act.FL_.vel, dq_.segment<3>(0), J_.FL.J,J_.FL.J_dot, Dyn_.M_.FL_.M3, Dyn_.CG_.FL_.CG3);
                Dyn_.Torque.FR_.SwingTorque = CalcTaskSpaceCTC(Ref.FR_.pos, Ref.FR_.vel, Ref.FR_.acc, Act.FR_.pos, Act.FR_.vel, dq_.segment<3>(3), J_.FR.J,J_.FR.J_dot, Dyn_.M_.FR_.M3, Dyn_.CG_.FR_.CG3);
                Dyn_.Torque.RL_.SwingTorque = CalcTaskSpaceCTC(Ref.RL_.pos, Ref.RL_.vel, Ref.RL_.acc, Act.RL_.pos, Act.RL_.vel, dq_.segment<3>(6), J_.RL.J,J_.RL.J_dot, Dyn_.M_.RL_.M3, Dyn_.CG_.RL_.CG3);
                Dyn_.Torque.RR_.SwingTorque = CalcTaskSpaceCTC(Ref.RR_.pos, Ref.RR_.vel, Ref.RR_.acc, Act.RR_.pos, Act.RR_.vel, dq_.segment<3>(9), J_.RR.J,J_.RR.J_dot, Dyn_.M_.RR_.M3, Dyn_.CG_.RR_.CG3);
            }
            else{
                Dyn_.Force.FL_.EEForce = CalcTaskSpaceForce(Ref.FL_.pos, Act.FL_.pos, Ref.FL_.vel, Act.FL_.vel);
                Dyn_.Torque.FL_.SwingTorque = J_.FL.J_Trs * R_Mtrx_Trs * Dyn_.Force.FL_.EEForce;
                Dyn_.Force.FR_.EEForce = CalcTaskSpaceForce(Ref.FR_.pos, Act.FR_.pos, Ref.FR_.vel, Act.FR_.vel);
                Dyn_.Torque.FR_.SwingTorque = J_.FR.J_Trs * R_Mtrx_Trs * Dyn_.Force.FR_.EEForce;
                Dyn_.Force.RL_.EEForce = CalcTaskSpaceForce(Ref.RL_.pos, Act.RL_.pos, Ref.RL_.vel, Act.RL_.vel);
                Dyn_.Torque.RL_.SwingTorque = J_.RL.J_Trs * R_Mtrx_Trs * Dyn_.Force.RL_.EEForce;
                Dyn_.Force.RR_.EEForce = CalcTaskSpaceForce(Ref.RR_.pos, Act.RR_.pos, Ref.RR_.vel, Act.RR_.vel);
                Dyn_.Torque.RR_.SwingTorque = J_.RR.J_Trs * R_Mtrx_Trs * Dyn_.Force.RR_.EEForce;
            }
        }
            Eigen::Vector3d DynamicsController::CalcTaskSpaceForce( Eigen::Vector3d& Ref_Pos,Eigen::Vector3d& Act_Pos, Eigen::Vector3d& Ref_Vel,Eigen::Vector3d& Act_Vel)
            {
                Eigen::Vector3d task_space_force = Eigen::Vector3d::Zero();
                Eigen::Vector3d pos_err = Ref_Pos - Act_Pos;
                Eigen::Vector3d vel_err = Ref_Vel - Act_Vel;
                double P_gain = 1200.0;  
                double D_gain = 10.0;  
                task_space_force = P_gain * pos_err + D_gain * vel_err;
                return task_space_force;
            }
            Eigen::Vector3d DynamicsController::CalcTaskSpaceCTC(   const Eigen::Vector3d& Ref_Pos, const Eigen::Vector3d& Ref_Vel, const Eigen::Vector3d& ddx_d, 
                                                                    const Eigen::Vector3d& Act_Pos, const Eigen::Vector3d& Act_Vel,    const Eigen::Vector3d& q_dot_,
                                                                    const Eigen::Matrix3d& J, const Eigen::Matrix3d& J_dot_, 
                                                                    const Eigen::Matrix3d& M, const Eigen::Vector3d& CG  )
            {

                double kp_scalar = 3500.0; // 위치 게인
                double kd_scalar = 50.0;  // 속도 게인

                Eigen::Matrix3d Kp = kp_scalar * Eigen::Matrix3d::Identity(); // 위치 게인 행렬
                Eigen::Matrix3d Kd = kd_scalar * Eigen::Matrix3d::Identity(); // 속도 게인 행렬

                // 2. 태스크 공간 오차 계산
                Eigen::Vector3d e_x = Ref_Pos - Act_Pos;
                Eigen::Vector3d e_dx = Ref_Vel - Act_Vel;

                Eigen::Vector3d ddx_des = ddx_d + Kp * e_x + Kd * e_dx;
                Eigen::Vector3d ddq_des;
                ddq_des = J.inverse() * (ddx_des - J_dot_ * q_dot_);

                Eigen::Vector3d tau = M * ddq_des + CG;

                return tau; // 계산된 조인트 토크 반환
            }
            
    void DynamicsController::QPController()
    {
        how_to_control_ = WBC_QP; // WBC_QP or SRBM_QP
        if (how_to_control_ == WBC_QP){
            applyGainsToQP(Walking_FLAG);

            // Equality 
            Eigen::Matrix<double,6,30>  Aeq   = PS_->CalcEqualityConstraint_A(foot_pos, Dyn_.M_.Body, Pattern_.SW_FLAG);
            Eigen::Matrix<double,6,1 >  Beq   = PS_->CalcEqualityConstraint_B(Dyn_.CG_.Body);
            // Inequality
            Eigen::Matrix<double,24,30> Aineq = PS_->CalcInequalityConstraint_A(Mu);
            Eigen::Matrix<double,24,1>  Bineq = PS_->CalcInequalityConstraint_B(-10.0, 300.0, Pattern_.SW_FLAG);
            // Cost function  
            Eigen::Matrix<double,30,30> CostA = PS_->CalcCostFuntion_A(J_.Body.Whole_Trs); 

            Eigen::Matrix<double,18,1 > Xddot = PS_->GetXddotVector(QP_.CoM_.KP, Ref.CoM_.pos.segment(0,3), Act.CoM_.pos.segment(0,3), 
                                                                    QP_.CoM_.KD, Ref.CoM_.vel.segment(0,3), Act.CoM_.vel.segment(0,3),
                                                                    QP_.RPY_.KP, Ref.CoM_.pos.segment(3,3), Act.CoM_.pos.segment(3,3),
                                                                    QP_.RPY_.KD, Ref.CoM_.vel.segment(3,3), Act.CoM_.vel.segment(3,3) );

            Eigen::Matrix<double,30,1 > CostB = PS_->CalcCostFuntion_B(Xddot, J_.Body.Whole_Dot, dq_state, J_.Body.Whole_Trs);
            Eigen::Matrix<double,30,1 > solution = PS_->WBC_QP(CostA, CostB, Aeq, Beq, Aineq, Bineq, J_.Body.Whole_Trs, Dyn_.M_.Leg);
            Eigen::Matrix<double,12,30 >WBC_Final_Torque_Mtrx = Eigen::Matrix<double,12,30>::Zero();
            WBC_Final_Torque_Mtrx.block(0, 0,  12, 18) = Dyn_.M_.Leg.block(0, 0, 12, 18);
            WBC_Final_Torque_Mtrx.block(0, 18, 12, 12) = J_.LEGs.transpose();
            WBC_Final_Torque= WBC_Final_Torque_Mtrx * solution; 

            // 스탠스 다리에만 토크 할당 
            if (Pattern_.SW_FLAG[_FL_] == 0) {
                Dyn_.Torque.FL_.Leg = WBC_Final_Torque.segment<3>(0);
                Dyn_.Force.FL_.QPLambda = solution.segment(18,3);
            } else {
                Dyn_.Torque.FL_.Leg = Dyn_.Torque.FL_.SwingTorque;
            }
            if (Pattern_.SW_FLAG[_FR_] == 0) {
                Dyn_.Torque.FR_.Leg = WBC_Final_Torque.segment<3>(3);
                Dyn_.Force.FR_.QPLambda = solution.segment(21,3);
            } else {
                Dyn_.Torque.FR_.Leg = Dyn_.Torque.FR_.SwingTorque;
            }
            if (Pattern_.SW_FLAG[_RL_] == 0) {
                Dyn_.Torque.RL_.Leg = WBC_Final_Torque.segment<3>(6);
                Dyn_.Force.RL_.QPLambda = solution.segment(24,3);
            } else {
                Dyn_.Torque.RL_.Leg = Dyn_.Torque.RL_.SwingTorque;
            }
            if (Pattern_.SW_FLAG[_RR_] == 0) {
                Dyn_.Torque.RR_.Leg = WBC_Final_Torque.segment<3>(9);
                Dyn_.Force.RR_.QPLambda = solution.segment(27,3);
            } else {
                Dyn_.Torque.RR_.Leg = Dyn_.Torque.RR_.SwingTorque;
            }
    
        }
        else if (how_to_control_ == SRBM_QP){
            Eigen::Matrix<double,12,1> SRBM_Output_Force = Eigen::Matrix<double,12,1>::Zero();
            // Cost Function
            Eigen::Matrix<double,6,12> A_ = SRBM_.Calc_Cost_A(foot_pos);
            Eigen::Matrix<double,6,1>  SRBM_Force = SRBM_.Calc_SRBM_Force(Ref.CoM_.pos, Ref.CoM_.vel, Act.CoM_.pos, Act.CoM_.vel, Walking_FLAG);
            Eigen::MatrixXd Cost_A = SRBM_.SetCostFunction_A(A_);
            Eigen::VectorXd Cost_B = SRBM_.SetCostFunction_B(A_, SRBM_Force);
            // Inequality
            double Friction = 0.5; // 마찰 계수
            Eigen::Matrix<double,24,12> Ineq_A = SRBM_.SetInequalityConstraint_G(Friction);
            Eigen::Matrix<double,24,1>  Ineq_b = SRBM_.SetInequalityConstraint_h(Pattern_.SW_FLAG, Walking_FLAG);

            SRBM_Output_Force = SRBM_.SRBM_QP(Cost_A, Cost_B, Ineq_A, Ineq_b);
            // 스탠스 다리에만 토크 할당
            if (Pattern_.SW_FLAG[_FL_] == 0) {
                Dyn_.Force.FL_.QPLambda = SRBM_Output_Force.segment<3>(0);
                Dyn_.Torque.FL_.Leg = J_.FL.J_Trs * R_Mtrx_Trs * Dyn_.Force.FL_.QPLambda;
            } else {
                Dyn_.Torque.FL_.Leg = Dyn_.Torque.FL_.SwingTorque;
            }
            if (Pattern_.SW_FLAG[_FR_] == 0) {
                Dyn_.Force.FR_.QPLambda = SRBM_Output_Force.segment<3>(3);
                Dyn_.Torque.FR_.Leg = J_.FR.J_Trs * R_Mtrx_Trs * Dyn_.Force.FR_.QPLambda;
            } else {
                Dyn_.Torque.FR_.Leg = Dyn_.Torque.FR_.SwingTorque;
            }
            if (Pattern_.SW_FLAG[_RL_] == 0) {
                Dyn_.Force.RL_.QPLambda = SRBM_Output_Force.segment<3>(6);
                Dyn_.Torque.RL_.Leg = J_.RL.J_Trs * R_Mtrx_Trs * Dyn_.Force.RL_.QPLambda;
            } else {
                Dyn_.Torque.RL_.Leg = Dyn_.Torque.RL_.SwingTorque;
            }
            if (Pattern_.SW_FLAG[_RR_] == 0) {
                Dyn_.Force.RR_.QPLambda = SRBM_Output_Force.segment<3>(9);
                Dyn_.Torque.RR_.Leg = J_.RR.J_Trs * R_Mtrx_Trs * Dyn_.Force.RR_.QPLambda;
            } else {
                Dyn_.Torque.RR_.Leg = Dyn_.Torque.RR_.SwingTorque;
            }
        }
        else{
                Dyn_.Torque.FL_.Leg.setZero();
                Dyn_.Torque.FR_.Leg.setZero();
                Dyn_.Torque.RL_.Leg.setZero();
                Dyn_.Torque.RR_.Leg.setZero();
                Dyn_.Torque.FL_.Leg = Dyn_.Torque.FL_.SwingTorque;
                Dyn_.Torque.FR_.Leg = Dyn_.Torque.FR_.SwingTorque;
                Dyn_.Torque.RL_.Leg = Dyn_.Torque.RL_.SwingTorque;
                Dyn_.Torque.RR_.Leg = Dyn_.Torque.RR_.SwingTorque;
            
        
        }
    }
    void DynamicsController::KickMode(int frontLeg)
    {
        // // frontLeg: 0=FL, 1=FR
        // Ref.CoM_.pos(_Y_) = -0.05; // + -> 왼쪽 - -> 오른쪽
    
        // frontLeg: 0=FL (왼발 킥 → 몸통 -Y), 1=FR (오른발 킥 → 몸통 +Y)
        static int  stepCount   = 0;
        const int   controlHz   = 500;
        const double duration   = 7.0;                         // 전체 모션 시간(초)
        const int   totalSteps  = int(controlHz * duration);   // 1500 스텝
        const int   phaseSteps  = totalSteps / 5;               // 4단계로 분할

        // 지금은 몸통 Y축 이동만 처리
        int   phase    = stepCount / phaseSteps;                           // 0,1,2,3
        double tLocal  = double(stepCount % phaseSteps) / phaseSteps;      // [0,1) 진행도
        double offset  = 0.05;                                             // 이동 거리 (m)
        double dir     = (frontLeg == 0 ? -1.0 : +1.0);                    // 킥 반대 방향

        double y = 0.0;
        if (phase == 0) {
            // Phase 0: 0→offset 를 quintic 으로 부드럽게 올리기
            double s = GC_.quintic(tLocal);
            y = dir * offset * s;
        }
        else if (phase == 1) {
            // Phase 1: offset 유지 + 다리 들어서 뒤로 당기기
            y = dir * offset;

            if (frontLeg == 0) {
                Pattern_.SW_FLAG[_FL_] = ON; // FL 킥
                Ref.FL_.pos(2) = ROBOT_STAND_HEIGHT - 0.05; // FL 킥 시 FL 발을 들어올림
            } else {
                Pattern_.SW_FLAG[_FR_] = ON; // FR 킥
                Ref.FR_.pos(2) = ROBOT_STAND_HEIGHT - 0.05; // FL 킥 시 FL 발을 들어올림
            }


        }
        else if (phase == 2) {
            // Phase 2: offset 유지 + 킥
            y = dir * offset;


            if (frontLeg == 0) {
                Pattern_.SW_FLAG[_FL_] = ON; // FL 킥
                Ref.FL_.pos(2) = ROBOT_STAND_HEIGHT - 0.05; // FL 킥 시 FL 발을 들어올림
            } else {
                Pattern_.SW_FLAG[_FR_] = ON; // FR 킥
                Ref.FR_.pos(2) = ROBOT_STAND_HEIGHT - 0.05; // FL 킥 시 FL 발을 들어올림
            }



        }
        else if (phase == 3) {
            // Phase 3: offset 유지 + 다리 제자리로 놓기
            y = dir * offset;


            if (frontLeg == 0) {
                Pattern_.SW_FLAG[_FL_] = ON; // FL 킥
                Ref.FL_.pos(2) = ROBOT_STAND_HEIGHT - 0.05; // FL 킥 시 FL 발을 들어올림
            } else {
                Pattern_.SW_FLAG[_FR_] = ON; // FR 킥
                Ref.FR_.pos(2) = ROBOT_STAND_HEIGHT - 0.05; // FL 킥 시 FL 발을 들어올림
            }




        }
        else if (phase == 4) {
            // Phase 4: offset→0 를 quintic 으로 부드럽게 내리기
            double s = GC_.quintic(tLocal);
            y = dir * offset * (1.0 - s);
            Pattern_.SW_FLAG[_FL_] = OFF; 
            Pattern_.SW_FLAG[_FR_] = OFF; 
        }

        // Y축 인덱스는 1번 (0:X, 1:Y, 2:Z)
        Ref.CoM_.pos(1) = y;
        // 카운터 업데이트 (3초 후 다시 0)
        stepCount = (stepCount + 1) % totalSteps;
    }

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void DynamicsController::PostProcessing()
{
    Eigen::Vector3d JointDamping;
    JointDamping << 0.1, 0.1, 0.1;
    applyVirtualDriveDamping(JointDamping);
    for (int i = 0; i < 3; ++i) {
        // RBQ
        // shared_memory_->Dyn_torque[i]   = Dyn_.Torque.RR_.Leg[i];
        // shared_memory_->Dyn_torque[i+3] = Dyn_.Torque.RL_.Leg[i];
        // shared_memory_->Dyn_torque[i+6] = Dyn_.Torque.FR_.Leg[i];
        // shared_memory_->Dyn_torque[i+9] = Dyn_.Torque.FL_.Leg[i];

        // Unitree
        shared_memory_->Dyn_torque[i]   = Dyn_.Torque.FR_.Leg[i];
        shared_memory_->Dyn_torque[i+3] = Dyn_.Torque.FL_.Leg[i];
        shared_memory_->Dyn_torque[i+6] = Dyn_.Torque.RR_.Leg[i];
        shared_memory_->Dyn_torque[i+9] = Dyn_.Torque.RL_.Leg[i];
        
        // Basic
        // shared_memory_->Dyn_torque[i]   = Dyn_.Torque.FL_.Leg[i];
        // shared_memory_->Dyn_torque[i+3] = Dyn_.Torque.FR_.Leg[i];
        // shared_memory_->Dyn_torque[i+6] = Dyn_.Torque.RL_.Leg[i];
        // shared_memory_->Dyn_torque[i+9] = Dyn_.Torque.RR_.Leg[i];
        
    }
    TCPDataStreamer();
}
    void DynamicsController::TCPDataStreamer()
    {
        std::ostringstream oss;
        oss << "px=" <<Act.CoM_.pos(0) << ",py=" << Act.CoM_.pos(1) << ",pz=" << Act.CoM_.pos(2) 
            << ",vx=" <<Act.CoM_.vel(0) << ",vy=" << Act.CoM_.vel(1) << ",vz=" << Act.CoM_.vel(2)
            << ",roll=" << Act.CoM_.pos(3) << ",pitch=" << Act.CoM_.pos(4) << ",yaw=" << Act.CoM_.pos(5)
            << ",droll=" << Act.CoM_.vel(3) << ",dpitch=" << Act.CoM_.vel(4) << ",dyaw=" << Act.CoM_.vel(5)
            << "\n";


        // oss << "footvelFLx=" << Act.FL_.vel(0) << 
        //     ",footvelFLy=" << Act.FL_.vel(1) << 
        //     ",footvelFLz=" << Act.FL_.vel(2) <<
        //     ",footvelFRx=" << Act.FR_.vel(0) << 
        //     ",footvelFRy=" << Act.FR_.vel(1) << 
        //     ",footvelFRz=" << Act.FR_.vel(2) <<
        //     ",footvelRLx=" << Act.RL_.vel(0) << 
        //     ",footvelRLy=" << Act.RL_.vel(1) << 
        //     ",footvelRLz=" << Act.RL_.vel(2) <<
        //     ",footvelRRx=" << Act.RR_.vel(0) << 
        //     ",footvelRRy=" << Act.RR_.vel(1) << 
        //     ",footvelRRz=" << Act.RR_.vel(2) <<
        //     ",slipFL=" << slip_Prob(0) <<
        //     ",slipFR=" << slip_Prob(1) <<
        //     ",slipRL=" << slip_Prob(2) <<
        //     ",slipRR=" << slip_Prob(3) <<
        //     "\n";
        tcp_server_.sendData(oss.str());
    }

Eigen::VectorXd DynamicsController::ReMapLegOrder(const std::vector<double>& q_in) 
{
    assert(q_in.size() == 12 && "ReMapLegOrder: input must have length 12");
    // static constexpr int idx_map[12] = {
    //     9,10,11,
    //     6, 7, 8,
    //     3, 4, 5,
    //     0, 1, 2
    // };
    static constexpr int idx_map[12] = {
        3, 4, 5,
        0, 1, 2, 
        9, 10, 11,
        6, 7, 8
    };
    Eigen::VectorXd q_out(12);
    for(int i = 0; i < 12; ++i) {
        q_out[i] = q_in[idx_map[i]];
    }
    return q_out;
}
DynamicsController::RobotConfig DynamicsController::loadConfig(const std::string& filename) 
{
    YAML::Node cfg = YAML::LoadFile(filename);
    RobotConfig rc;
    rc.name = cfg["robot"]["name"].as<std::string>();

    for (auto mode_it : cfg["WBC"]) {
        std::string mode_name = mode_it.first.as<std::string>(); 
        ModeGains mg;
        for (auto axis_it : mode_it.second) {
            std::string axis = axis_it.first.as<std::string>();
            Gain g;
            g.kp = axis_it.second["kp"].as<double>();
            g.kd = axis_it.second["kd"].as<double>();
            mg[axis] = g;
        }
        rc.wbc[mode_name] = mg;
    }
    return rc;
}
void DynamicsController::applyGainsToQP(bool walking_flag) 
{
    // 모드 결정
    const std::string mode = walking_flag ? "Walking" : "Standing";
    const ModeGains& mg = robot_config_.wbc.at(mode);

    // CoM (X, Y, Z)
    QP_.CoM_.KP << mg.at("X").kp, mg.at("Y").kp, mg.at("Z").kp;
    QP_.CoM_.KD << mg.at("X").kd, mg.at("Y").kd, mg.at("Z").kd;

    // RPY (roll, pitch, yaw)
    QP_.RPY_.KP << mg.at("roll").kp,  mg.at("pitch").kp,  mg.at("yaw").kp;
    QP_.RPY_.KD << mg.at("roll").kd,  mg.at("pitch").kd,  mg.at("yaw").kd;
}
void DynamicsController::applyVirtualDriveDamping(Eigen::Vector3d& JointDamping)
{
    Dyn_.Torque.FL_.Leg(0) -= JointDamping[0]*dq_(0);
    Dyn_.Torque.FL_.Leg(1) -= JointDamping[1]*dq_(1);
    Dyn_.Torque.FL_.Leg(2) -= JointDamping[2]*dq_(2);

    Dyn_.Torque.FR_.Leg(0) -= JointDamping[0]*dq_(3);
    Dyn_.Torque.FR_.Leg(1) -= JointDamping[1]*dq_(4);
    Dyn_.Torque.FR_.Leg(2) -= JointDamping[2]*dq_(5);

    Dyn_.Torque.RL_.Leg(0) -= JointDamping[0]*dq_(6);
    Dyn_.Torque.RL_.Leg(1) -= JointDamping[1]*dq_(7);
    Dyn_.Torque.RL_.Leg(2) -= JointDamping[2]*dq_(8);
    
    Dyn_.Torque.RR_.Leg(0) -= JointDamping[0]*dq_(9);
    Dyn_.Torque.RR_.Leg(1) -= JointDamping[1]*dq_(10);
    Dyn_.Torque.RR_.Leg(2) -= JointDamping[2]*dq_(11);

}
    