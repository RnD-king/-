#include "BRP_Kinematics.hpp"
#include "NewPattern2.hpp"
#include <cmath>
#include <algorithm>
#include <vector>
using namespace Eigen;
using namespace std;
using namespace BRP_Kinematics;
#define deg2rad 0.017453292519943
#define rad2deg 57.295779513082323
#define PI 3.141592653589793

Trajectory::Trajectory()
{
	walkfreq = 1.48114; // 1초 걸음 수 (보행 주파수 Hz)
	walktime = 2 / walkfreq; // 왼발 오른발 나누어 두번 걸으므로..!
	freq = 100; // 제어 루프의 주파수!
	walktime_n = walktime * freq; // 한 걸음동안 제어 루프가 몇 번 도는지 (샘플 수)!
	del_t = 1 / freq; // 제어루프의 시간 간격!
	z_c = 1.2 * 0.28224;  // CoM 높이 -> 1.2는 scale factor!
	g = 9.81; // 중력가속도!
	T_prev = 1.5; // Preview 제어 시간!
	NL = T_prev * freq; // Preview 샘플 수!
	A << 1, del_t, del_t * del_t / 2, // 시스템의 상태 : 위치 속도 가속도
		0, 1, del_t,
		0, 0, 1;
	B << del_t * del_t * del_t / 6, del_t * del_t / 2, del_t; // 입력 행렬 - 가속도를 제어 입력 취급
	C << 1, 0, -z_c / g; // CoM 위치와 가속도로 ZMP 계산
	
	
	////////////////// 가중치 행렬 //////////////////
	Qe = 1; // ZMP 오차에 대한 가중치
	Qx = Matrix3d::Zero(); // 상태 가중치 (위치, 속도, 가속도에 대한 penalty=0)
	Q_p = Matrix4d::Zero(); // Preview 제어용 결합 가중치 행렬
	Q_p << Qe, 0, 0, 0,
		0, Qx(0, 0), Qx(0, 1), Qx(0, 2),
		0, Qx(1, 0), Qx(1, 1), Qx(1, 2),
		0, Qx(2, 0), Qx(2, 1), Qx(2, 2);	// zmp 오차와 상태 가중치 조합 행렬 
	R << pow(10, -6);
	I_p << 1, 0, 0, 0;
	
	//// Preview 제어용 B,A 행렬 확장 //////
	B_p.row(0) = C * B;
	B_p.row(1) = B.row(0);
	B_p.row(2) = B.row(1);
	B_p.row(3) = B.row(2);	// ZMP 오차를 포함한 입력 행렬

	F_p.row(0) = C * A;
	F_p.row(1) = A.row(0);
	F_p.row(2) = A.row(1);
	F_p.row(3) = A.row(2);	// ZMP 오차를 포함한 상태 행렬

	A_p = Matrix4d::Identity();
	A_p.block<4, 3>(0, 1) = F_p;	// Preview 제어용 확장 상태 행렬

	K_p << 41.1035354770549, 824.198546618308, 163.877879931218, 0.866971302114951,
		824.198546618308, 17489.6862079445, 3483.96465227876, 19.6487374770632,
		163.877879931218, 3483.96465227876, 694.154076281009, 3.94329494961909,
		0.866971302114951, 19.6487374770632, 3.94329494961909, 0.0282399782535132;		// 미리 계산된 LQR Gain 행렬

	/////////// Preview Controller Gain Calculation /////////////
	Gi = (R + B_p.transpose() * K_p * B_p).inverse() * B_p.transpose() * K_p * I_p;		// 오차누적에 대한 이득 (zmp 오차 적분 -> 제어입력 변환)
	Gx = (R + B_p.transpose() * K_p * B_p).inverse() * B_p.transpose() * K_p * F_p;		// 현재 상태에 대한 이득
	Gd = MatrixXd::Zero(NL, 1);		// Preview Horizon에 대한 feedforward 이득
	Ac_p = A_p - B_p * (R + B_p.transpose() * K_p * B_p).inverse() * B_p.transpose() * K_p * A_p;
	zmp_err_int = 0;	// ZMP 오차 적분값 초기화
	u_prev = 0;		// 이전 제어 입력 초기화
	step = 0.05;	// 한 스텝 거리
	step_n = 0;		
	sim_n = 0;
	sim_time = 0;	// 시뮬레이션 관련 카운터 초기화
	Angle_trajectorty_turn << 0, 0, 0, 0, 0, 0;	
	Angle_trajectorty_back << 0, 0, 0, 0, 0, 0;		// 보행 중 회전 및 후진 동작용 궤적 초기화

	XStep << 0, 0, 0, 0, 0, 0;
	XStride << 0, 0, 0, 0, 0, 0;		// 보행 스텝 별 위치 및 보폭 값 초기화
};

void Trajectory::Change_Freq(double f)		// 보폭 속도를 조절할때 사용
{
	walktime = f / walkfreq;
	walktime_n = walktime * freq;
}		// 외부 인자 f를 기준으로 walktime(보행주기), walktime_n(제어 샘플 수) 다시 계산

void Trajectory::Set_step(double a)	{ step = a; }	// 보폭 크기를 바꾸고 싶을 때 사용  

void Trajectory::Set_distance(double Goal_distance, double YPos)		// ZMP 및 CoM 궤적 생성을 위한 기준 위치 벡터 Ref_X,Ypos 설정
{ 
	step_n = (Goal_distance + 2 * step) / (2 * step);	// 스텝 수 계산
	sim_n = walktime_n * step_n;	// 시뮬레이션 프레임 수 - zmp, com 궤적 생성 수

	Ref_Xpos = VectorXd::Zero(2 * step_n);	// 전진방향 기준 위치 (보폭 기준)
	for (int i = 0; i < (2 * step_n); i++){
		if (i == 0) Ref_Xpos(i) = 0;
		else if (i < 2 * step_n - 1) Ref_Xpos(i) = step * (i - 1);
		else if (i == 2 * step_n - 1) Ref_Xpos(i) = step * (i - 2);
	}

	Ref_Ypos = VectorXd::Zero(2 * step_n);		// 좌우 보행 기준 위치
	for (int i = 0; i < (2 * step_n); i++){
		if (i < 1) Ref_Ypos(i) = 0;
		else if (i > 2 * step_n - 2) Ref_Ypos(i) = 0;
		else if ((i + 1) % 2 == 0) Ref_Ypos(i) = YPos;
		else if ((i + 1) % 2 == 1) Ref_Ypos(i) = -0.055;
	}
}

void Trajectory::Set_distance_start(double Goal_distance) // 위의 함수와 같으나, 시작할때 사용인지, 보행중 사용인지 차이
{
	step_n = (Goal_distance + 2 * step) / (2 * step);
	sim_n = walktime_n * step_n;

	Ref_Xpos = VectorXd::Zero(2 * step_n);
	for (int i = 0; i < (2 * step_n); i++){
		if (i == 0) Ref_Xpos(i) = 0;
		else if (i < 2 * step_n - 1) Ref_Xpos(i) = step * (i - 1);
		else if (i == 2 * step_n - 1) Ref_Xpos(i) = step * (i - 2);
	}

	Ref_Ypos = VectorXd::Zero(2 * step_n);
	for (int i = 0; i < (2 * step_n); i++){
		if (i < 1) Ref_Ypos(i) = 0;
		else if (i > 2 * step_n - 2) Ref_Ypos(i) = 0;
		else if ((i + 1) % 2 == 0) Ref_Ypos(i) = 0.057;
		else if ((i + 1) % 2 == 1) Ref_Ypos(i) = -0.06;
	}
}

void Trajectory::Set_distance_back(double Goal_distance)	// 뒤로 걷기를 위한,,
{
	step_n = (Goal_distance + 2 * step) / (2 * step);
	sim_n = walktime_n * step_n;

	Ref_Xpos = VectorXd::Zero(2 * step_n);
	for (int i = 0; i < (2 * step_n); i++){
		if (i == 0) Ref_Xpos(i) = 0;
		else if (i < 2 * step_n - 1) Ref_Xpos(i) = (step-0.007) * (i - 1);
		else if (i == 2 * step_n - 1) Ref_Xpos(i) = (step) * (i - 2);
	}

	Ref_Ypos = VectorXd::Zero(2 * step_n);
	for (int i = 0; i < (2 * step_n); i++){
		if (i < 1) Ref_Ypos(i) = 0;
		else if (i > 2 * step_n - 2) Ref_Ypos(i) = 0;
		else if ((i + 1) % 2 == 0) Ref_Ypos(i) = 0.055; //0.065
		else if ((i + 1) % 2 == 1) Ref_Ypos(i) = -0.05; //-0.05
	}
}

double Trajectory::Return_Step_n() { return step_n; }		// 현재 보행 거리 기준으로 계산된 step 수
int Trajectory::Return_Walktime_n() { return walktime_n; }		// 한 걸음 동안 제어 루프가 몇 번 도는지 반환
int Trajectory::Return_Sim_n() { return sim_n; }		// 전체 보행 시뮬레이션 프레임 수 (걸음 수 * walktime_n)

MatrixXd Trajectory::PreviewGd(){		// Preview control의 이득 행렬 Gd 계산
	for (int l = 0; l < NL; l++)
	{

		Matrix4d temp = Ac_p.transpose();
		for (int i = 1; i < l; i++){
			temp = temp * Ac_p.transpose();
		}
		Gd(l, 0) = (R + B_p.transpose() * K_p * B_p).inverse() * B_p.transpose() * temp * K_p * I_p;
		if (l == 0)
			Gd(l, 0) = (R + B_p.transpose() * K_p * B_p).inverse() * B_p.transpose() * K_p * I_p;
	}
	return Gd;
};

MatrixXd Trajectory::XComSimulation()		// X축 방향으로 com이 어떻게 이동해야 zmp 기준에 맞춰 움직일 수 있을지 궤적 계산
{
	PreviewGd();
	zmp_err_int = 0;
	u_prev = 0;
	int Com_flag = 0;
	float float_Com_flag = 0;
	float float_walktime_n = walktime_n;
	RowVectorXd zmp_ref(sim_n + 19);
	for (int i = 0; i < sim_n + 19; i++)
	{
		if (i < float_walktime_n) zmp_ref(i) = 0;
		else if (i > sim_n - 1) zmp_ref(i) = Ref_Xpos(2 * step_n - 1);
		else if (i < (float_Com_flag * 0.5 + 0.5) * float_walktime_n) zmp_ref(i) = Ref_Xpos(Com_flag);
		else if (i < (float_Com_flag * 0.5 + 1) * float_walktime_n) zmp_ref(i) = Ref_Xpos(Com_flag + 1);
		
		if ((i + 1) % walktime_n == 0){
			Com_flag = Com_flag + 2;
			float_Com_flag = float_Com_flag + 2;
		}
	}

	VectorXd zmp_ref_fifo(NL);
	VectorXd u(sim_n + 19);
	VectorXd zmp(sim_n + 19);
	VectorXd zmp_ref_final(sim_n + 19);
	VectorXd CP(sim_n + 19);
	MatrixXd XCom(3, sim_n + 20);
	zmp_ref_fifo.setZero();
	u.setZero();
	zmp.setZero();
	zmp_ref_final.setZero();
	CP.setZero();
	XCom.setZero();
	double w = sqrt(g / z_c);
	for (int i = 0; i < sim_n + 19; i++){
		for (int j = 0; j < NL; j++){
			if (i + j < sim_n + 19) zmp_ref_fifo[j] = zmp_ref[i + j];
			else zmp_ref_fifo[j] = zmp_ref[sim_n + 18];
		}
		u_prev = 0;
		for (int j = 0; j < NL; j++){
			u_prev += Gd(j, 0) * zmp_ref_fifo[j];
		}
		u[i] = Gi * zmp_err_int - Gx * XCom.col(i) + u_prev;
		XCom.col(i + 1) = A * XCom.col(i) + B * u[i];
		zmp[i] = C * XCom.col(i);
		zmp_err_int += (zmp_ref[i] - zmp[i]);
		CP[i] = XCom(0, i) + 1 / w * XCom(1, i);
		zmp_ref_final[i] = zmp_ref[i];
	}
	xzmp_ref = zmp_ref;
	ref_xCP = CP.block(18, 0, sim_n, 1);
	MatrixXd XCom_ = XCom.block(0, 18, 1, sim_n);
	return XCom_;
};

MatrixXd Trajectory::YComSimulation()		// Y축 방향으로 com이 어떻게 이동해야 zmp 기준에 맞춰 움직일 수 있을지 궤적 계산
{
	PreviewGd();
	zmp_err_int = 0;
	u_prev = 0;
	int Com_flag = 0;
	float float_Com_flag = 0;
	float float_walktime_n = walktime_n;
	RowVectorXd zmp_ref(sim_n + 19);

	for (int i = 0; i < sim_n + 19; i++) {
		if (i > sim_n - 1) zmp_ref(i) = 0;
		else if (i < (float_Com_flag * 0.5 + 0.5) * float_walktime_n) zmp_ref(i) = Ref_Ypos(Com_flag);
		else if (i < (float_Com_flag * 0.5 + 1) * float_walktime_n) zmp_ref(i) = Ref_Ypos(Com_flag + 1);

		if ((i + 1) % walktime_n == 0) {
			Com_flag = Com_flag + 2;
			float_Com_flag = float_Com_flag + 2;
		}
	}

	VectorXd zmp_ref_fifo(NL);
	VectorXd u(sim_n + 19);
	VectorXd zmp(sim_n + 19);
	VectorXd zmp_ref_final(sim_n + 19);
	VectorXd CP(sim_n + 19);
	MatrixXd YCom(3, sim_n + 20);
	zmp_ref_fifo.setZero();
	u.setZero();
	zmp.setZero();
	zmp_ref_final.setZero();
	CP.setZero();
	YCom.setZero();
	double w = sqrt(g / z_c);
	for (int i = 0; i < sim_n + 19; i++){
		for (int j = 0; j < NL; j++){
			if (i + j < sim_n + 19) zmp_ref_fifo[j] = zmp_ref[i + j];
			else zmp_ref_fifo[j] = zmp_ref[sim_n + 18];
		}
		u_prev = 0;
		for (int j = 0; j < NL; j++){
			u_prev = u_prev + Gd(j, 0) * zmp_ref_fifo[j];
		}
		u[i] = Gi * zmp_err_int - Gx * YCom.col(i) + u_prev;
		YCom.col(i + 1) = A * YCom.col(i) + B * u[i];
		zmp[i] = C * YCom.col(i);
		zmp_err_int += (zmp_ref[i] - zmp[i]);
		CP[i] = YCom(0, i) + 1.0 / w * YCom(1, i);
		zmp_ref_final[i] = zmp_ref[i];
	}
	yzmp_ref = zmp_ref;
	ref_yCP = CP.block(18, 0, sim_n, 1);
	MatrixXd YCom_ = YCom.block(0, 18, 1, sim_n);
	return YCom_;
}
//////////////////////////////////////////////////////////
VectorXd Trajectory::Get_xCP() {return ref_xCP;}

VectorXd Trajectory::Get_yCP() {return ref_yCP;}

RowVectorXd Trajectory::Get_xZMP() {return xzmp_ref;}

RowVectorXd Trajectory::Get_yZMP() {return yzmp_ref;}



//////////////////// 5차 방정식 궤적 계산기 /////////////////////
MatrixXd Trajectory::Equation_solver(double t0, double t1, double start, double end)
{
	Matrix<double, 6, 6> A;
	Matrix<double, 6, 1> B;
	Matrix<double, 6, 1> X;
	A << 1, t0, pow(t0, 2), pow(t0, 3), pow(t0, 4), pow(t0, 5),
		0, 1, 2 * t0, 3 * pow(t0, 2), 4 * pow(t0, 3), 5 * pow(t0, 4),
		0, 0, 2, 6 * t0, 12 * pow(t0, 2), 20 * pow(t0, 3),
		1, t1, pow(t1, 2), pow(t1, 3), pow(t1, 4), pow(t1, 5),
		0, 1, 2 * t1, 3 * pow(t1, 2), 4 * pow(t1, 3), 5 * pow(t1, 4),
		0, 0, 2, 6 * t1, 12 * pow(t1, 2), 20 * pow(t1, 3);
	B << start, 0, 0, end, 0, 0;
	X = A.colPivHouseholderQr().solve(B);
	return X;
};

double Trajectory::Sinusoidal(double t, double T, double h) {return h * 0.5 * (1 - cos(PI * t / T));}

double Trajectory::Step(double t){
	double X = XStep(0) + XStep(1) * t + XStep(2) * pow(t, 2) + XStep(3) * pow(t, 3) + XStep(4) * pow(t, 4) + XStep(5) * pow(t, 5);
	return X;
};

double Trajectory::Stride(double t){
	double X = XStride(0) + XStride(1) * t + XStride(2) * pow(t, 2) + XStride(3) * pow(t, 3) + XStride(4) * pow(t, 4) + XStride(5) * pow(t, 5);
	return X;
};

double Trajectory::XSN(double t){
	double X = Xsn(0) + Xsn(1) * t + Xsn(2) * pow(t, 2) + Xsn(3) * pow(t, 3) + Xsn(4) * pow(t, 4) + Xsn(5) * pow(t, 5);
	return X;
};

/////////////////// 발 경로 계산기 /////////////////////////////////////////

MatrixXd Trajectory::RF_xsimulation_straightwalk(){
	int sim_n = step_n * walktime_n;
	double dwalktime_n = walktime_n;
	double Rfootflag = 0;

	RowVectorXd Footpos(sim_n);
	Footpos.setZero();
	
	for (int i = 0; i < sim_n; i++)
	{
		if (i < 0.6 * dwalktime_n) Footpos[i] = 0;
		
		else if (i < 0.9 * dwalktime_n) {
			double t_rel = i - 0.6 * walktime_n;
			Footpos[i] = Sinusoidal(t_rel, walktime_n*0.3, step);
		}
		else if (i < 1.1 * dwalktime_n) Footpos[i] = step;
		else if (i < (Rfootflag + 0.6) * dwalktime_n) Footpos[i] = (2 * Rfootflag - 1) * step;
		else if (i < (Rfootflag + 0.9) * dwalktime_n) {
			double t_rel = i - (0.6 + Rfootflag) * walktime_n;
			Footpos[i] = Sinusoidal(t_rel, walktime_n *0.3, 2*step) + (2 * Rfootflag - 1) * step;
		}
		
		else if (i < (Rfootflag + 1.1) * dwalktime_n) Footpos[i] = (2 * Rfootflag + 1) * step;
		else Footpos[i] = (2 * step_n - 3) * step;

		if ((i + 1) % walktime_n == 0)
		{
			if (Rfootflag < step_n - 2) Rfootflag = Rfootflag + 1;
		}
	};
	return Footpos;
};

MatrixXd Trajectory::LF_xsimulation_straightwalk()
{
	int sim_n = step_n * walktime_n;
	double dwalktime_n = walktime_n;
	double Lfootflag = 0;

	RowVectorXd Footpos(sim_n);
	Footpos.setZero();

	for (int i = 0; i < sim_n; i++)
	{
		if (i < 1.1 * walktime_n) Footpos[i] = 0;
		else if (i < (Lfootflag + 0.1) * walktime_n) Footpos[i] = (2 * Lfootflag - 2) * step;
		else if (i < (Lfootflag + 0.4) * walktime_n){
			double t_rel = i - (Lfootflag + 0.1) * dwalktime_n;
			Footpos[i] = Sinusoidal(t_rel, walktime_n * 0.3, 2* step) + (2 * Lfootflag - 2) * step;
		}

		else if (i < (Lfootflag + 1.1) * walktime_n) Footpos[i] = (2 * Lfootflag) * step;

		else if (i < (step_n - 0.6) * walktime_n) {
			double t_rel = i - (Lfootflag + 1.1) * dwalktime_n;
			Footpos[i] = Sinusoidal(t_rel, walktime_n * 0.3, step) + (2 * step_n - 4) * step;
		}

		else Footpos[i] = (2 * step_n - 3) * step;

		if ((i + 1) % walktime_n == 0)
		{
			if (Lfootflag < step_n - 2) Lfootflag = Lfootflag + 1;
		}
	};
	return Footpos;
}

MatrixXd Trajectory::RF_zsimulation_straightwalk(double h) 
{
    int sim_n = step_n * walktime_n;
	double dwalktime_n = walktime_n;
    double Rfootflag = 0;

    RowVectorXd Footpos(sim_n);
    Footpos.setZero();

    for (int i = 0; i < sim_n; i++) {
        double rise_start = (Rfootflag + 0.55) * dwalktime_n;
        double rise_end   = (Rfootflag + 0.75) * dwalktime_n;
        double fall_end   = (Rfootflag + 0.95) * dwalktime_n;

		double T = 0.2 * dwalktime_n;

		if (i < rise_start) Footpos[i] = 0;

        else if (i >= rise_start && i < rise_end) {
            double phase_time = i - rise_start;
            Footpos[i] = Sinusoidal(phase_time, T, h);  // 올림
        }
        else if (i >= rise_end && i < fall_end) {
            double phase_time = fall_end - i;
            Footpos[i] = Sinusoidal(phase_time, T, h);  // 내림
        }
		else if (i  < (Rfootflag + 1) * dwalktime_n) Footpos[i] = 0;
		else Footpos[i] = 0;

        if ((i + 1) % walktime_n == 0) {
            if (Rfootflag < step_n - 2) Rfootflag += 1;
        }
    }

    return Footpos;
}

MatrixXd Trajectory::LF_zsimulation_straightwalk(double h) {
    int sim_n = step_n * walktime_n;
	double dwalktime_n = walktime_n;
    double Lfootflag = 0;

    RowVectorXd Footpos(sim_n);
    Footpos.setZero();

    for (int i = 0; i < sim_n; i++) {
		double rise_start = (Lfootflag + 0.05) * dwalktime_n;
		double rise_end   = (Lfootflag + 0.25) * dwalktime_n;
		double fall_end   = (Lfootflag + 0.45) * dwalktime_n;

		double T = 0.2 * dwalktime_n;  // cos traj. 

		if (i < 1.05 * dwalktime_n) Footpos[i] = 0;

        else if (i >= rise_start && i < rise_end) {
            double phase_time = i - rise_start;
            Footpos[i] = Sinusoidal(phase_time, T, h);  // 올림
        }
        else if (i >= rise_end && i < fall_end) {
            double phase_time = fall_end - i;
            Footpos[i] = Sinusoidal(phase_time, T, h);  // 내림
        }
		else if (i < (Lfootflag + 0.5) * dwalktime_n) Footpos[i] = 0;

		else Footpos[i] = 0;

        if ((i + 1) % walktime_n == 0) {
            if (Lfootflag < step_n - 1) Lfootflag += 1;
        }
    }

    return Footpos;
}



// standard : body.. so, foot -> body  = sit motion 
// For Pick and huddle 
MatrixXd Trajectory::zsimulation_sitdown_pick(int FB_sim_n, double h)
{
	RowVectorXd Footpos(FB_sim_n);
	double T = 0.6 * FB_sim_n;
	for (int i = 0; i < FB_sim_n; i++)
	{
		if (i < FB_sim_n * 0.2) Footpos[i] = 0;
		else if (i < FB_sim_n * 0.8){
			double t_rel = i - FB_sim_n*0.2;
			Footpos[i] = Sinusoidal(t_rel, T, h);
		}
		else if (i < FB_sim_n) Footpos[i] = h;
		else Footpos[i] = h;
	};
	return Footpos;
}

MatrixXd Trajectory::zsimulation_standup_pick(int FB_sim_n, double h)
{
	RowVectorXd Footpos(FB_sim_n);
	double T = 0.6 * FB_sim_n;
	for (int i = 0; i < FB_sim_n; i++)
	{
		if (i < FB_sim_n * 0.2) Footpos[i] = h;
		else if (i < FB_sim_n * 0.8) {
			double t_rel = i - FB_sim_n*0.2;
			Footpos[i] = h - Sinusoidal(t_rel, T, h);
		}
		else if (i < FB_sim_n) Footpos[i] = 0;
		else Footpos[i] = 0;
	};
	return Footpos;
}


// For huddle motion. 
MatrixXd Trajectory::RF_zsimulation_sitdown(double h)
{
	RowVectorXd Footpos(100);
	double T = 60.0;  // 상승 시간 (프레임 기준)
	for (int i = 0; i < 100; i++)
	{
		if (i < 20) Footpos[i] = 0;
		else if (i < 80) {
			double t_rel = i - 20;
			Footpos[i] = Sinusoidal(t_rel, T, h);  // 5차 궤적 대신 사인 궤적
		}
		else Footpos[i] = h;
	}
	return Footpos;
}

MatrixXd Trajectory::LF_zsimulation_sitdown(double h)
{
	RowVectorXd Footpos(100);
	double T = 60.0;  // 상승 시간 (프레임 기준)

	for (int i = 0; i < 100; i++)
	{
		if (i < 20) Footpos[i] = 0;
		else if (i < 80) {
			double t_rel = i - 20;
			Footpos[i] = Sinusoidal(t_rel, T, h);  // 5차 궤적 대신 사인 궤적
		}
		else Footpos[i] = h;
	}

	return Footpos;
}

MatrixXd Trajectory::RF_zsimulation_standup(double h)
{
	RowVectorXd Footpos(100);
	double T = 60.0;
	for (int i = 0; i < 100; i++)
	{
		if (i < 20) Footpos[i] = h;
		else if (i < 80){
			double t_rel = i -20;
			Footpos[i] = h - Sinusoidal(t_rel,T, h);
		}
		else if (i < 100) Footpos[i] = 0;
		else Footpos[i] = 0;
	};
	return Footpos;
}

MatrixXd Trajectory::LF_zsimulation_standup(double h)
{
	RowVectorXd Footpos(100);
	double T = 60.0;
	for (int i = 0; i < 100; i++)
	{
		if (i < 20) Footpos[i] = h;
		else if (i < 80){
			double t_rel = i -20;
			Footpos[i] = h - Sinusoidal(t_rel,T, h);
		}
		else if (i < 100) Footpos[i] = 0;
		else Footpos[i] = 0;
	};
	return Footpos;
}

MatrixXd Trajectory::z_position_sitdown(int M_sim_n, double h)
{
	RowVectorXd Footpos(M_sim_n);
	for (int i = 0; i < M_sim_n; i++)
	{
		Footpos[i] = h;
	};
	return Footpos;
}








void Trajectory::Go_Straight(double step, double distance, double height)
{
	Set_step(step);
	Set_distance(distance, 0.06);
	Xcom = XComSimulation();
	Ycom = YComSimulation();
	LF_xFoot = LF_xsimulation_straightwalk();
	RF_xFoot = RF_xsimulation_straightwalk();
	RF_yFoot = -L0 * MatrixXd::Ones(1, sim_n);
	LF_yFoot = L0 * MatrixXd::Ones(1, sim_n);
	Ref_RL_x = RF_xFoot - Xcom;
	Ref_LL_x = LF_xFoot - Xcom; // ++
	Ref_RL_y = RF_yFoot - Ycom;
	Ref_LL_y = LF_yFoot - Ycom;
	Ref_RL_z = RF_zsimulation_straightwalk(height);
	Ref_LL_z = LF_zsimulation_straightwalk(height);
}

void Trajectory::Go_Straight_start(double step, double distance, double height)
{
	Set_step(step);
	Set_distance_start(distance);
	Xcom = XComSimulation();
	Ycom = YComSimulation();
	LF_xFoot = LF_xsimulation_straightwalk();
	RF_xFoot = RF_xsimulation_straightwalk();
	RF_yFoot = -L0 * MatrixXd::Ones(1, sim_n);
	LF_yFoot = L0 * MatrixXd::Ones(1, sim_n);
	Ref_RL_x = RF_xFoot - Xcom;
	Ref_LL_x = LF_xFoot - Xcom;
	Ref_RL_y = RF_yFoot - Ycom;
	Ref_LL_y = LF_yFoot - Ycom;
	Ref_RL_z = RF_zsimulation_straightwalk(height);
	Ref_LL_z = LF_zsimulation_straightwalk(height);
}


void Trajectory::Freq_Change_Straight(double step, double distance, double height, double freq)
{
	Change_Freq(freq);
	Set_step(step);
	Set_distance(distance, 0.06);

	MatrixXd Xcom_ = XComSimulation();
	MatrixXd Ycom_ = YComSimulation();
	MatrixXd LF_xFoot = LF_xsimulation_straightwalk();
	MatrixXd RF_xFoot = RF_xsimulation_straightwalk();
	MatrixXd RF_yFoot = -L0 * MatrixXd::Ones(1, sim_n);
	MatrixXd LF_yFoot = L0 * MatrixXd::Ones(1, sim_n);
	Ref_RL_x = RF_xFoot - Xcom_;
	Ref_LL_x = LF_xFoot - Xcom_;
	Ref_RL_y = RF_yFoot - Ycom_;
	Ref_LL_y = LF_yFoot - Ycom_;
	Ref_RL_z = RF_zsimulation_straightwalk(height);
	Ref_LL_z = LF_zsimulation_straightwalk(height);
}

void Trajectory::Make_turn_trajectory(double angle)
{
    Turn_Trajectory = VectorXd::Zero(walktime_n);

    double T_rise = walktime_n * 0.3;  // 올라가는 구간 시간
    double T_fall = walktime_n * 0.3;  // 내려가는 구간 시간

    for (int i = 0; i < walktime_n; i++)
    {
        if (i < 0.1 * walktime_n) Turn_Trajectory(i) = 0;
        else if (i < 0.4 * walktime_n) {
            double t_rel = i - 0.1 * walktime_n;
            Turn_Trajectory(i) = Sinusoidal(t_rel, T_rise, angle); // 상승 궤적 (0 → angle)
        }
        else if (i < 0.6 * walktime_n) Turn_Trajectory(i) = angle; // remain 
        else if (i < 0.9 * walktime_n) {
            double t_rel = i - 0.6 * walktime_n;
            Turn_Trajectory(i) = Sinusoidal(t_rel, T_fall, angle);
            Turn_Trajectory(i) = angle - Turn_Trajectory(i);  // 반전, 하강 궤적 (angle → 0)
        }
        else Turn_Trajectory(i) = 0;
    }
}

void Trajectory::Picking_Motion(int FB_sim_n, int M_sim_n, double COM_h)
{
	MatrixXd Ref_RL_x_t = MatrixXd::Zero(1, M_sim_n);
	MatrixXd Ref_LL_x_t = MatrixXd::Zero(1, M_sim_n);
	MatrixXd Ref_RL_y_t = -L0 * MatrixXd::Ones(1, M_sim_n);
	MatrixXd Ref_LL_y_t = L0 * MatrixXd::Ones(1, M_sim_n);
	MatrixXd Ref_RL_z_t = z_position_sitdown(M_sim_n, COM_h);
	MatrixXd Ref_LL_z_t = z_position_sitdown(M_sim_n, COM_h);
	MatrixXd Temp_RL_x(Ref_RL_x_t.rows(), MatrixXd::Zero(1, FB_sim_n).cols() + Ref_RL_x_t.cols() + MatrixXd::Zero(1, FB_sim_n).cols());
	MatrixXd Temp_LL_x(Ref_LL_x_t.rows(), MatrixXd::Zero(1, FB_sim_n).cols() + Ref_LL_x_t.cols() + MatrixXd::Zero(1, FB_sim_n).cols());
	MatrixXd Temp_RL_y(Ref_RL_y_t.rows(), MatrixXd::Ones(1, FB_sim_n).cols() + Ref_RL_y_t.cols() + MatrixXd::Ones(1, FB_sim_n).cols());
	MatrixXd Temp_LL_y(Ref_LL_y_t.rows(), MatrixXd::Ones(1, FB_sim_n).cols() + Ref_LL_y_t.cols() + MatrixXd::Ones(1, FB_sim_n).cols());
	MatrixXd Temp_RL_z(Ref_RL_z_t.rows(), zsimulation_sitdown_pick(FB_sim_n, COM_h).cols() + Ref_RL_z_t.cols() + zsimulation_standup_pick(FB_sim_n, COM_h).cols());
	MatrixXd Temp_LL_z(Ref_LL_z_t.rows(), zsimulation_sitdown_pick(FB_sim_n, COM_h).cols() + Ref_LL_z_t.cols() + zsimulation_standup_pick(FB_sim_n, COM_h).cols());
	Temp_RL_x << MatrixXd::Zero(1, FB_sim_n), Ref_RL_x_t, MatrixXd::Zero(1, FB_sim_n);
	Temp_LL_x << MatrixXd::Zero(1, FB_sim_n), Ref_LL_x_t, MatrixXd::Zero(1, FB_sim_n);
	Temp_RL_y << -L0 * MatrixXd::Ones(1, FB_sim_n), Ref_RL_y_t, -L0 * MatrixXd::Ones(1, FB_sim_n);
	Temp_LL_y << L0 * MatrixXd::Ones(1, FB_sim_n), Ref_LL_y_t, L0 * MatrixXd::Ones(1, FB_sim_n);
	Temp_RL_z << zsimulation_sitdown_pick(FB_sim_n, COM_h), Ref_RL_z_t, zsimulation_standup_pick(FB_sim_n, COM_h);
	Temp_LL_z << zsimulation_sitdown_pick(FB_sim_n, COM_h), Ref_LL_z_t, zsimulation_standup_pick(FB_sim_n, COM_h);
	Ref_RL_x = Temp_RL_x;
	Ref_LL_x = Temp_LL_x;
	Ref_RL_y = Temp_RL_y;
	Ref_LL_y = Temp_LL_y;
	Ref_RL_z = Temp_RL_z;
	Ref_LL_z = Temp_LL_z;

}






IK_Function::IK_Function()
{
	walkfreq = 1.48114;
	walktime = 2 / walkfreq;
	freq = 100;
	walktime_n = walktime * freq;
	step = 0.05;
	freq = 100;
	step_n = 0;
	sim_n = 0;
	sim_time = 0;

	RL_th[0] = 0. * deg2rad;   // RHY
	RL_th[1] = 0. * deg2rad;   // RHR
	RL_th[2] = -35. * deg2rad; // RHP
	RL_th[3] = 70. * deg2rad;  // RKN
	RL_th[4] = -35. * deg2rad; // RAP
	RL_th[5] = 0. * deg2rad;   // RAR

	LL_th[0] = 0. * deg2rad;   // LHY
	LL_th[1] = 0. * deg2rad;   // LHR
	LL_th[2] = -35. * deg2rad; // LHP
	LL_th[3] = 70. * deg2rad;  // LKN
	LL_th[4] = -35. * deg2rad; // LAP
	LL_th[5] = 0. * deg2rad;   // LAR

	Ref_RL_PR[0] = 40.;
	Ref_RL_PR[1] = -L0;
	Ref_RL_PR[2] = -L1 - L2 - L3 - L4 - L5 - L6 + 40.;
	Ref_RL_PR[3] = 0 * deg2rad;
	Ref_RL_PR[4] = 0 * deg2rad;
	Ref_RL_PR[5] = 0 * deg2rad;

	Ref_LL_PR[0] = 40.;
	Ref_LL_PR[1] = L0;
	Ref_LL_PR[2] = -L1 - L2 - L3 - L4 - L5 - L6 + 40.;
	Ref_LL_PR[3] = 0 * deg2rad;
	Ref_LL_PR[4] = 0 * deg2rad;
	Ref_LL_PR[5] = 0 * deg2rad;

	RL_Support_Leg = 0;
	RL_Swing_Leg = 0;
	RL_Support_Knee = 0;
	LL_Support_Leg = 0;
	LL_Swing_Leg = 0;
	LL_Support_Knee = 0;
	Com_Height = 30;
}

void IK_Function::Get_Step_n(double a)
{
	step_n = a;
	sim_n = walktime_n * step_n;
}

void IK_Function::BRP_Simulation(const MatrixXd& RFx, const MatrixXd& RFy, const MatrixXd& RFz, 
                                 const MatrixXd& LFx, const MatrixXd& LFy, const MatrixXd& LFz, 
                                 int Index_CNT)
{
    // Index_CNT가 유효한 범위 내에 있는지 확인하고 조정
    int idx = std::min(Index_CNT, static_cast<int>(RFx.cols())) - 1;

	// Ref_RL_PR와 Ref_LL_PR 배열 초기화
    Ref_RL_PR[0] = 1000 * RFx(0, idx);
    Ref_RL_PR[1] = 1000 * RFy(0, idx);
    Ref_RL_PR[2] = -L1 - L2 - L3 - L4 - L5 - L6 + Com_Height + 1000 * RFz(0, idx);
    Ref_RL_PR[3] = 0 * deg2rad;
    Ref_RL_PR[4] = 0 * deg2rad;
    Ref_RL_PR[5] = 0 * deg2rad;

    Ref_LL_PR[0] = 1000 * LFx(0, idx);
    Ref_LL_PR[1] = 1000 * LFy(0, idx);
    Ref_LL_PR[2] = -L1 - L2 - L3 - L4 - L5 - L6 + Com_Height + 1000 * LFz(0, idx);
    Ref_LL_PR[3] = 0 * deg2rad;
    Ref_LL_PR[4] = 0 * deg2rad;
    Ref_LL_PR[5] = 0 * deg2rad;

	Eigen::Map<Eigen::VectorXd> RL_th_vec(RL_th, 6);
    Eigen::Map<Eigen::VectorXd> LL_th_vec(LL_th, 6);
    Eigen::Map<Eigen::VectorXd> Ref_RL_PR_vec(Ref_RL_PR, 6);
    Eigen::Map<Eigen::VectorXd> Ref_LL_PR_vec(Ref_LL_PR, 6);

	Eigen::VectorXd link(7);
	link << L0, L1, L2, L3, L4, L5, L6;
 	
    Eigen::VectorXd RL_th_IK_vec(6), LL_th_IK_vec(6);

	BRP_Kinematics::BRP_RL_IK(Ref_RL_PR_vec, RL_th_vec, link, RL_th_IK_vec);
    BRP_Kinematics::BRP_LL_IK(Ref_LL_PR_vec, LL_th_vec, link, LL_th_IK_vec);

	std::memcpy(RL_th, RL_th_IK_vec.data(), 6 * sizeof(double));
    std::memcpy(LL_th, LL_th_IK_vec.data(), 6 * sizeof(double));

}


void IK_Function::Change_Com_Height(double h)
{
	Com_Height = h;
}

void IK_Function::Set_Angle_Compensation(int walktime_n)
{
	Trajectory traj;

	RL_Compensation_Support_Leg_up = traj.Equation_solver(0, walktime_n * 0.075, 0, RL_Support_Leg);
	RL_Compensation_Support_Leg_down = traj.Equation_solver(0, walktime_n * 0.075, RL_Support_Leg, 0);
	RL_Compensation_Swing_Leg_up = traj.Equation_solver(0, walktime_n * 0.075, 0, RL_Swing_Leg);
	RL_Compensation_Swing_Leg_down = traj.Equation_solver(0, walktime_n * 0.075, RL_Swing_Leg, 0);
	RL_Compensation_Support_knee_up = traj.Equation_solver(0, walktime_n * 0.075, 0, RL_Support_Knee);
	RL_Compensation_Support_knee_down = traj.Equation_solver(0, walktime_n * 0.075, RL_Support_Knee, 0);
	RL_Compensation_Support_ankle_up = traj.Equation_solver(0, walktime_n * 0.075, 0, RL_Support_Ankle);
	RL_Compensation_Support_ankle_down = traj.Equation_solver(0, walktime_n * 0.075, RL_Support_Ankle, 0);

	LL_Compensation_Support_Leg_up = traj.Equation_solver(0, walktime_n * 0.075, 0, LL_Support_Leg);
	LL_Compensation_Support_Leg_down = traj.Equation_solver(0, walktime_n * 0.075, LL_Support_Leg, 0);
	LL_Compensation_Swing_Leg_up = traj.Equation_solver(0, walktime_n * 0.075, 0, LL_Swing_Leg);
	LL_Compensation_Swing_Leg_down = traj.Equation_solver(0, walktime_n * 0.075, LL_Swing_Leg, 0);
	LL_Compensation_Support_knee_up = traj.Equation_solver(0, walktime_n * 0.075, 0, LL_Support_Knee);
	LL_Compensation_Support_knee_down = traj.Equation_solver(0, walktime_n * 0.075, LL_Support_Knee, 0);
	LL_Compensation_Support_ankle_up = traj.Equation_solver(0, walktime_n * 0.075, 0, LL_Support_Ankle);
	LL_Compensation_Support_ankle_down = traj.Equation_solver(0, walktime_n * 0.075, LL_Support_Ankle, 0);
}

void IK_Function::Change_Angle_Compensation(double RL_Support, double RL_Swing, double RL_Knee, double RL_Ankle, double LL_Support, double LL_Swing, double LL_Knee, double LL_Ankle)
{
	RL_Support_Leg = RL_Support * deg2rad;
	RL_Swing_Leg = RL_Swing * deg2rad;
	RL_Support_Knee = RL_Knee * deg2rad; //-5 * deg2rad;
	RL_Support_Ankle = RL_Ankle * deg2rad;

	LL_Support_Leg = LL_Support * deg2rad;
	LL_Swing_Leg = LL_Swing * deg2rad;
	LL_Support_Knee = LL_Knee * deg2rad; //-5 * deg2rad;
	LL_Support_Ankle = LL_Ankle * deg2rad;
}

void IK_Function::Angle_Compensation(int indext, int size)
{

	double check_index = indext % walktime_n;
	double dwalktime = walktime_n;
	if (indext > 74 && indext < size + walktime_n)
	{
		if (check_index > 0.075 * dwalktime && check_index < 0.15 * dwalktime) // swing
			LL_th[1] = LL_th[1] + LL_Swing_Leg_Compensation_up(check_index - 0.075 * dwalktime);
		else if (check_index > 0.15 * dwalktime && check_index < 0.35 * dwalktime)
			LL_th[1] = LL_th[1] + LL_Swing_Leg;
		else if (check_index > 0.35 * dwalktime && check_index < 0.425 * dwalktime)
			LL_th[1] = LL_th[1] + LL_Swing_Leg_Compensation_down(check_index - 0.35 * dwalktime);
		else if (check_index > 0.575 * dwalktime && check_index < 0.65 * dwalktime) // support
		{
			LL_th[1] = LL_th[1] + LL_Support_Leg_Compensation_up(check_index - 0.575 * dwalktime);
			LL_th[3] = LL_th[3] + LL_Support_Knee_Compensation_up(check_index - 0.575 * dwalktime);
			LL_th[4] = LL_th[4] + LL_Support_Ankle_Compensation_up(check_index - 0.575 * dwalktime);
			LL_th[5] = LL_th[5] + LL_Support_Leg_Compensation_up(check_index - 0.575 * dwalktime);
		}
		else if (check_index > 0.65 * dwalktime && check_index < 0.85 * dwalktime) // support
		{
			LL_th[1] = LL_th[1] + LL_Support_Leg;
			LL_th[3] = LL_th[3] + LL_Support_Knee;
			LL_th[4] = LL_th[4] + LL_Support_Ankle;
			LL_th[5] = LL_th[5] + LL_Support_Leg;
		}
		else if (check_index > 0.85 * dwalktime && check_index < 0.925 * dwalktime) { // support
			LL_th[1] = LL_th[1] + LL_Support_Leg_Compensation_down(check_index - 0.85 * dwalktime);
			LL_th[3] = LL_th[3] + LL_Support_Knee_Compensation_down(check_index - 0.85 * dwalktime);
			LL_th[4] = LL_th[4] + LL_Support_Ankle_Compensation_down(check_index - 0.85 * dwalktime);
			LL_th[5] = LL_th[5] + LL_Support_Leg_Compensation_down(check_index - 0.85 * dwalktime);
		}

		if (check_index > 0.075 * dwalktime && check_index < 0.15 * dwalktime) { // support
			RL_th[1] = RL_th[1] - RL_Support_Leg_Compensation_up(check_index - 0.075 * dwalktime);
			RL_th[3] = RL_th[3] - RL_Support_Knee_Compensation_up(check_index - 0.075 * dwalktime);
			RL_th[4] = RL_th[4] - RL_Support_Ankle_Compensation_up(check_index - 0.075 * dwalktime);
			RL_th[5] = RL_th[5] - RL_Support_Leg_Compensation_up(check_index - 0.075 * dwalktime);
		}
		else if (check_index > 0.15 * dwalktime && check_index < 0.35 * dwalktime){
			RL_th[1] = RL_th[1] - RL_Support_Leg;
			RL_th[3] = RL_th[3] - RL_Support_Knee;
			RL_th[4] = RL_th[4] - RL_Support_Ankle;
			RL_th[5] = RL_th[5] - RL_Support_Leg;
		}
		else if (check_index > 0.35 * dwalktime && check_index < 0.425 * dwalktime){
			RL_th[1] = RL_th[1] - RL_Support_Leg_Compensation_down(check_index - 0.35 * dwalktime);
			RL_th[3] = RL_th[3] - RL_Support_Knee_Compensation_down(check_index - 0.35 * dwalktime);
			RL_th[4] = RL_th[4] - RL_Support_Ankle_Compensation_down(check_index - 0.35 * dwalktime);
			RL_th[5] = RL_th[5] - RL_Support_Leg_Compensation_down(check_index - 0.35 * dwalktime);
		}

		else if (check_index > 0.575 * dwalktime && check_index < 0.65 * dwalktime) // swing
			RL_th[1] = RL_th[1] - RL_Swing_Leg_Compensation_up(check_index - 0.575 * dwalktime);
		
		else if (check_index > 0.65 * dwalktime && check_index < 0.85 * dwalktime) // swing
			RL_th[1] = RL_th[1] - RL_Swing_Leg;
		else if (check_index > 0.85 * dwalktime && check_index < 0.925 * dwalktime) // swing
			RL_th[1] = RL_th[1] - RL_Swing_Leg_Compensation_down(check_index - 0.85 * dwalktime);
	}
}

void IK_Function::Fast_Angle_Compensation(int indext)
{
	int fwalktime_n = walktime_n * 0.5;
	double dwalktime = fwalktime_n;
	double check_index = indext % fwalktime_n;

	if (indext > 0.5 * dwalktime && indext < sim_n + dwalktime)
	{
		if (check_index > 0.075 * dwalktime && check_index < 0.15 * dwalktime) // swing
			LL_th[1] = LL_th[1] + LL_Swing_Leg_Compensation_up(check_index - 0.075 * dwalktime);
		else if (check_index > 0.15 * dwalktime && check_index < 0.35 * dwalktime)
			LL_th[1] = LL_th[1] + LL_Swing_Leg;
		else if (check_index > 0.35 * dwalktime && check_index < 0.425 * dwalktime)
			LL_th[1] = LL_th[1] + LL_Swing_Leg_Compensation_down(check_index - 0.35 * dwalktime);
		else if (check_index > 0.575 * dwalktime && check_index < 0.65 * dwalktime) // support
		{
			LL_th[1] = LL_th[1] + LL_Support_Leg_Compensation_up(check_index - 0.575 * dwalktime);
			LL_th[3] = LL_th[3] + LL_Support_Knee_Compensation_up(check_index - 0.575 * dwalktime);
			LL_th[4] = LL_th[4] + LL_Support_Ankle_Compensation_up(check_index - 0.575 * dwalktime);
			LL_th[5] = LL_th[5] + LL_Support_Leg_Compensation_up(check_index - 0.575 * dwalktime);
		}
		else if (check_index > 0.65 * dwalktime && check_index < 0.85 * dwalktime) // support
		{
			LL_th[1] = LL_th[1] + LL_Support_Leg;
			LL_th[3] = LL_th[3] + LL_Support_Knee;
			LL_th[4] = LL_th[4] + LL_Support_Ankle;
			LL_th[5] = LL_th[5] + LL_Support_Leg;
		}
		else if (check_index > 0.85 * dwalktime && check_index < 0.925 * dwalktime) // support
		{
			LL_th[1] = LL_th[1] + LL_Support_Leg_Compensation_down(check_index - 0.85 * dwalktime);
			LL_th[3] = LL_th[3] + LL_Support_Knee_Compensation_down(check_index - 0.85 * dwalktime);
			LL_th[4] = LL_th[4] + LL_Support_Ankle_Compensation_down(check_index - 0.85 * dwalktime);
			LL_th[5] = LL_th[5] + LL_Support_Leg_Compensation_down(check_index - 0.85 * dwalktime);
		}

		if (check_index > 0.075 * dwalktime && check_index < 0.15 * dwalktime) // support
		{
			RL_th[1] = RL_th[1] - RL_Support_Leg_Compensation_up(check_index - 0.075 * dwalktime);
			RL_th[3] = RL_th[3] - RL_Support_Knee_Compensation_up(check_index - 0.075 * dwalktime);
			RL_th[5] = RL_th[5] - RL_Support_Leg_Compensation_up(check_index - 0.075 * dwalktime);
		}
		else if (check_index > 0.15 * dwalktime && check_index < 0.35 * dwalktime)
		{
			RL_th[1] = RL_th[1] - RL_Support_Leg;
			RL_th[3] = RL_th[3] - RL_Support_Knee;
			RL_th[4] = RL_th[4] - RL_Support_Ankle;
			RL_th[5] = RL_th[5] - RL_Support_Leg;
		}
		else if (check_index > 0.35 * dwalktime && check_index < 0.425 * dwalktime)
		{
			RL_th[1] = RL_th[1] - RL_Support_Leg_Compensation_down(check_index - 0.35 * dwalktime);
			RL_th[3] = RL_th[3] - RL_Support_Knee_Compensation_down(check_index - 0.35 * dwalktime);
			RL_th[5] = RL_th[5] - RL_Support_Leg_Compensation_down(check_index - 0.35 * dwalktime);
		}

		else if (check_index > 0.575 * dwalktime && check_index < 0.65 * dwalktime) // swing
			RL_th[1] = RL_th[1] - RL_Swing_Leg_Compensation_up(check_index - 0.575 * dwalktime);
		else if (check_index > 0.65 * dwalktime && check_index < 0.85 * dwalktime) // swing
			RL_th[1] = RL_th[1] - RL_Swing_Leg;
		else if (check_index > 0.85 * dwalktime && check_index < 0.925 * dwalktime) // swing
			RL_th[1] = RL_th[1] - RL_Swing_Leg_Compensation_down(check_index - 0.85 * dwalktime);
	}
}

double IK_Function::RL_Swing_Leg_Compensation_up(double t)
{
	double X = RL_Compensation_Swing_Leg_up(0) + RL_Compensation_Swing_Leg_up(1) * t + RL_Compensation_Swing_Leg_up(2) * pow(t, 2) + RL_Compensation_Swing_Leg_up(3) * pow(t, 3) + RL_Compensation_Swing_Leg_up(4) * pow(t, 4) + RL_Compensation_Swing_Leg_up(5) * pow(t, 5);
	return X;
};
double IK_Function::RL_Support_Leg_Compensation_up(double t)
{
	double X = RL_Compensation_Support_Leg_up(0) + RL_Compensation_Support_Leg_up(1) * t + RL_Compensation_Support_Leg_up(2) * pow(t, 2) + RL_Compensation_Support_Leg_up(3) * pow(t, 3) + RL_Compensation_Support_Leg_up(4) * pow(t, 4) + RL_Compensation_Support_Leg_up(5) * pow(t, 5);
	return X;
};
double IK_Function::RL_Swing_Leg_Compensation_down(double t)
{
	double X = RL_Compensation_Swing_Leg_down(0) + RL_Compensation_Swing_Leg_down(1) * t + RL_Compensation_Swing_Leg_down(2) * pow(t, 2) + RL_Compensation_Swing_Leg_down(3) * pow(t, 3) + RL_Compensation_Swing_Leg_down(4) * pow(t, 4) + RL_Compensation_Swing_Leg_down(5) * pow(t, 5);
	return X;
};
double IK_Function::RL_Support_Leg_Compensation_down(double t)
{
	double X = RL_Compensation_Support_Leg_down(0) + RL_Compensation_Support_Leg_down(1) * t + RL_Compensation_Support_Leg_down(2) * pow(t, 2) + RL_Compensation_Support_Leg_down(3) * pow(t, 3) + RL_Compensation_Support_Leg_down(4) * pow(t, 4) + RL_Compensation_Support_Leg_down(5) * pow(t, 5);
	return X;
};
double IK_Function::RL_Support_Knee_Compensation_up(double t)
{
	double X = RL_Compensation_Support_knee_up(0) + RL_Compensation_Support_knee_up(1) * t + RL_Compensation_Support_knee_up(2) * pow(t, 2) + RL_Compensation_Support_knee_up(3) * pow(t, 3) + RL_Compensation_Support_knee_up(4) * pow(t, 4) + RL_Compensation_Support_knee_up(5) * pow(t, 5);
	return X;
};
double IK_Function::RL_Support_Knee_Compensation_down(double t)
{
	double X = RL_Compensation_Support_knee_down(0) + RL_Compensation_Support_knee_down(1) * t + RL_Compensation_Support_knee_down(2) * pow(t, 2) + RL_Compensation_Support_knee_down(3) * pow(t, 3) + RL_Compensation_Support_knee_down(4) * pow(t, 4) + RL_Compensation_Support_knee_down(5) * pow(t, 5);
	return X;
};
double IK_Function::RL_Support_Ankle_Compensation_up(double t)
{
	double X = RL_Compensation_Support_ankle_up(0) + RL_Compensation_Support_ankle_up(1) * t + RL_Compensation_Support_ankle_up(2) * pow(t, 2) + RL_Compensation_Support_ankle_up(3) * pow(t, 3) + RL_Compensation_Support_ankle_up(4) * pow(t, 4) + RL_Compensation_Support_ankle_up(5) * pow(t, 5);
	return X;
};
double IK_Function::RL_Support_Ankle_Compensation_down(double t)
{
	double X = RL_Compensation_Support_ankle_down(0) + RL_Compensation_Support_ankle_down(1) * t + RL_Compensation_Support_ankle_down(2) * pow(t, 2) + RL_Compensation_Support_ankle_down(3) * pow(t, 3) + RL_Compensation_Support_ankle_down(4) * pow(t, 4) + RL_Compensation_Support_ankle_down(5) * pow(t, 5);
	return X;
};

double IK_Function::LL_Swing_Leg_Compensation_up(double t)
{
	double X = LL_Compensation_Swing_Leg_up(0) + LL_Compensation_Swing_Leg_up(1) * t + LL_Compensation_Swing_Leg_up(2) * pow(t, 2) + LL_Compensation_Swing_Leg_up(3) * pow(t, 3) + LL_Compensation_Swing_Leg_up(4) * pow(t, 4) + LL_Compensation_Swing_Leg_up(5) * pow(t, 5);
	return X;
};
double IK_Function::LL_Support_Leg_Compensation_up(double t)
{
	double X = LL_Compensation_Support_Leg_up(0) + LL_Compensation_Support_Leg_up(1) * t + LL_Compensation_Support_Leg_up(2) * pow(t, 2) + LL_Compensation_Support_Leg_up(3) * pow(t, 3) + LL_Compensation_Support_Leg_up(4) * pow(t, 4) + LL_Compensation_Support_Leg_up(5) * pow(t, 5);
	return X;
};
double IK_Function::LL_Swing_Leg_Compensation_down(double t)
{
	double X = LL_Compensation_Swing_Leg_down(0) + LL_Compensation_Swing_Leg_down(1) * t + LL_Compensation_Swing_Leg_down(2) * pow(t, 2) + LL_Compensation_Swing_Leg_down(3) * pow(t, 3) + LL_Compensation_Swing_Leg_down(4) * pow(t, 4) + LL_Compensation_Swing_Leg_down(5) * pow(t, 5);
	return X;
};
double IK_Function::LL_Support_Leg_Compensation_down(double t)
{
	double X = LL_Compensation_Support_Leg_down(0) + LL_Compensation_Support_Leg_down(1) * t + LL_Compensation_Support_Leg_down(2) * pow(t, 2) + LL_Compensation_Support_Leg_down(3) * pow(t, 3) + LL_Compensation_Support_Leg_down(4) * pow(t, 4) + LL_Compensation_Support_Leg_down(5) * pow(t, 5);
	return X;
};
double IK_Function::LL_Support_Knee_Compensation_up(double t)
{
	double X = LL_Compensation_Support_knee_up(0) + LL_Compensation_Support_knee_up(1) * t + LL_Compensation_Support_knee_up(2) * pow(t, 2) + LL_Compensation_Support_knee_up(3) * pow(t, 3) + LL_Compensation_Support_knee_up(4) * pow(t, 4) + LL_Compensation_Support_knee_up(5) * pow(t, 5);
	return X;
};
double IK_Function::LL_Support_Knee_Compensation_down(double t)
{
	double X = LL_Compensation_Support_knee_down(0) + LL_Compensation_Support_knee_down(1) * t + LL_Compensation_Support_knee_down(2) * pow(t, 2) + LL_Compensation_Support_knee_down(3) * pow(t, 3) + LL_Compensation_Support_knee_down(4) * pow(t, 4) + LL_Compensation_Support_knee_down(5) * pow(t, 5);
	return X;
};
double IK_Function::LL_Support_Ankle_Compensation_up(double t)
{
	double X = LL_Compensation_Support_ankle_up(0) + LL_Compensation_Support_ankle_up(1) * t + LL_Compensation_Support_ankle_up(2) * pow(t, 2) + LL_Compensation_Support_ankle_up(3) * pow(t, 3) + LL_Compensation_Support_ankle_up(4) * pow(t, 4) + LL_Compensation_Support_ankle_up(5) * pow(t, 5);
	return X;
};
double IK_Function::LL_Support_Ankle_Compensation_down(double t)
{
	double X = LL_Compensation_Support_ankle_down(0) + LL_Compensation_Support_ankle_down(1) * t + LL_Compensation_Support_ankle_down(2) * pow(t, 2) + LL_Compensation_Support_ankle_down(3) * pow(t, 3) + LL_Compensation_Support_ankle_down(4) * pow(t, 4) + LL_Compensation_Support_ankle_down(5) * pow(t, 5);
	return X;
};
