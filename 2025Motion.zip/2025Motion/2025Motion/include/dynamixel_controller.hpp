#ifndef DYNAMIXEL_CONTROLLER_H
#define DYNAMIXEL_CONTROLLER_H

#include "dynamixel.hpp"
#include <Eigen/Dense>

// 이동평균필터 윈도우 크기
constexpr int kWindowSize = 2;

class DxlController
{
public:
    // Constructor
    explicit DxlController(Dxl *dxl_ptr);

    // Getters
    virtual Eigen::VectorXd GetJointTheta();
    virtual Eigen::VectorXd GetThetaDot();
    virtual Eigen::VectorXd GetThetaDotMAF();
    virtual Eigen::VectorXd GetTorque();

    // Setters
    virtual void SetTorque(const Eigen::VectorXd& tau);
    virtual void SetPosition(const Eigen::VectorXd& theta);

    // Public member variables (가능하면 private/protected 권장)
    Dxl *dxl_ptr_;
    Eigen::VectorXd th_cont_ = Eigen::VectorXd::Zero(kNumberOfDynamixels);
    Eigen::VectorXd th_dot_cont_ = Eigen::VectorXd::Zero(kNumberOfDynamixels);
    Eigen::VectorXd th_dot_mov_avg_filtered_ = Eigen::VectorXd::Zero(kNumberOfDynamixels); // Moving Average Filtered
    Eigen::MatrixXd maf_ = Eigen::MatrixXd::Zero(kWindowSize, kNumberOfDynamixels);
    Eigen::VectorXd torque_cont_ = Eigen::VectorXd::Zero(kNumberOfDynamixels);
};

#endif  // DYNAMIXEL_CONTROLLER_H
