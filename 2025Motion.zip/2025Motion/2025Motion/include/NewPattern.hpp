#pragma once
#include <eigen3/Eigen/Dense>
#include <iostream>
#include <cmath>
#define DEG2rad 0.017453292519943

class Trajectory {
private:
	//Com member
	double walkfreq;
	double walktime;
	int walktime_n;
	double freq;
	double step;
	int step_n;
	double del_t;
	double z_c;
	double g;
	double T_prev;
	int NL;
	int sim_n;
	Matrix3d A;
	Vector3d B;
	RowVector3d C;
	double Qe;
	Matrix3d Qx;
	Matrix4d Q_p;
	Matrix<double, 1, 1> R;
	Vector4d I_p;
	Vector4d B_p;
	Matrix<double, 4, 3> F_p;
	Matrix4d A_p;
	Matrix4d K_p;
	double Gi;
	Matrix<double, 1, 3> Gx;
	Matrix4d Ac_p;
	MatrixXd Gd;
	double sim_time;
	RowVectorXd xzmp_ref;
	RowVectorXd yzmp_ref;

	
	VectorXd zmp_ref;
	VectorXd zmp_ref_fifo;
	VectorXd u;
	VectorXd zmp;
	VectorXd zmp_ref_final;
	VectorXd ref_xCP;
	VectorXd ref_yCP;
	double zmp_err_int;
	double u_prev;
	VectorXd Ref_Xpos;
	VectorXd Ref_Ypos;
	bool check_DD = true;
	Matrix<double, 6, 1> Angle_trajectorty_turn;
	Matrix<double, 6, 1> Angle_trajectorty_back;
	//Footmember
	Matrix<double, 6, 1> XStep;
	Matrix<double, 6, 1> XStride;
    Matrix<double, 6, 1> Xsn;
	double L0 = 0.06;



public:

	Trajectory();
	void Change_Freq(double f);
	// for Com
	void Set_step(double a);
	void Set_distance(double Goal_distance, double YPos);
	void Set_distance_start(double Goal_distance);

	void Set_distance_back(double Goal_distance);
	MatrixXd PreviewGd();
	double Return_Step_n();
	int Return_Walktime_n();
	int Return_Sim_n();
	VectorXd Get_xCP();
	VectorXd Get_yCP();
	RowVectorXd Get_xZMP();
	RowVectorXd Get_yZMP();
	MatrixXd YComSimulation();
	MatrixXd XComSimulation();

	MatrixXd Equation_solver(double t0, double t1, double start, double end);
	
	void V_des(double v_des);

	double Sinusoidal(double t, double T, double h);
	double Step(double t);
	double Stride(double t);
	double XSN(double t);
	MatrixXd RF_xsimulation_straightwalk();
	MatrixXd LF_xsimulation_straightwalk();
	MatrixXd RF_zsimulation_straightwalk(double h);
	MatrixXd LF_zsimulation_straightwalk(double h);

	void Go_Straight(double step, double distance, double height);
	void Go_Straight_start(double step, double distance, double height);
	void Go_Back_Straight(double step, double distance, double height);
	void Go_Back(double step, double distance, double height);
	void Freq_Change_Straight(double step, double distance, double height, double freq);


	MatrixXd Ref_RL_x;
	MatrixXd Ref_RL_y;
	MatrixXd Ref_RL_z;
	MatrixXd Ref_LL_x;
	MatrixXd Ref_LL_y;
	MatrixXd Ref_LL_z;

	MatrixXd lsRef_RL_x;
	MatrixXd lsRef_RL_y;
	MatrixXd lsRef_RL_z;
	MatrixXd lsRef_LL_x;
	MatrixXd lsRef_LL_y;
	MatrixXd lsRef_LL_z;
	MatrixXd rsRef_RL_x;
	MatrixXd rsRef_RL_y;
	MatrixXd rsRef_RL_z;
	MatrixXd rsRef_LL_x;
	MatrixXd rsRef_LL_y;
	MatrixXd rsRef_LL_z;
/////////////////////////////////////////////////////////////////com and foot position
	MatrixXd Xcom;
	MatrixXd Ycom;
	MatrixXd LF_xFoot;
	MatrixXd RF_xFoot;
	MatrixXd RF_yFoot;
	MatrixXd LF_yFoot;

	VectorXd Turn_Trajectory;
};

class IK_Function
{
private:
	double walkfreq;
	double walktime;
	int walktime_n;
	double freq;
	double step;
	int step_n;
	double sim_time;
	int sim_n;

	//Inverse_kinematics member
	double L0 = 60;
	double L1 = 35.64;
	double L2 = 36.07;
	double L3 = 121.89;
	double L4 = 111.76;
	double L5 = 36.10;
	double L6 = 42.58;

	double FW = 92.8;
	double FL = 137.8;
	double RL_th_IK[6] = { 0.,0.,0.,0.,0.,0. }, LL_th_IK[6] = { 0.,0.,0.,0.,0.,0. };
	double Ref_RL_PR[6] = { 0.,0.,0.,0.,0.,0. }, Ref_LL_PR[6] = { 0.,0.,0.,0.,0.,0. };
	double RL_th_FK[6] = { 0.,0.,0.,0.,0.,0. }, RL_PR_FK[6] = { 0.,0.,0.,0.,0.,0. };
	double LL_th_FK[6] = { 0.,0.,0.,0.,0.,0. }, LL_PR_FK[6] = { 0.,0.,0.,0.,0.,0. };
	double Foot_Height = 0;
	Matrix<double, 6, 1> RL_Compensation_Support_Leg_up;
	Matrix<double, 6, 1> RL_Compensation_Support_Leg_down;
	Matrix<double, 6, 1> RL_Compensation_Swing_Leg_up;
	Matrix<double, 6, 1> RL_Compensation_Swing_Leg_down;
	Matrix<double, 6, 1> RL_Compensation_Support_knee_up;
	Matrix<double, 6, 1> RL_Compensation_Support_knee_down;
	Matrix<double, 6, 1> RL_Compensation_Support_ankle_up;
	Matrix<double, 6, 1> RL_Compensation_Support_ankle_down;
	double RL_Swing_Leg_Compensation_up(double t);
	double RL_Swing_Leg_Compensation_down(double t);
	double RL_Support_Leg_Compensation_up(double t);
	double RL_Support_Leg_Compensation_down(double t);
	double RL_Support_Knee_Compensation_up(double t);
	double RL_Support_Knee_Compensation_down(double t);
	double RL_Support_Ankle_Compensation_up(double t);
	double RL_Support_Ankle_Compensation_down(double t);
	double RL_Support_Leg;
	double RL_Swing_Leg;
	double RL_Support_Knee;
	double RL_Support_Ankle;

	Matrix<double, 6, 1> LL_Compensation_Support_Leg_up;
	Matrix<double, 6, 1> LL_Compensation_Support_Leg_down;
	Matrix<double, 6, 1> LL_Compensation_Swing_Leg_up;
	Matrix<double, 6, 1> LL_Compensation_Swing_Leg_down;
	Matrix<double, 6, 1> LL_Compensation_Support_knee_up;
	Matrix<double, 6, 1> LL_Compensation_Support_knee_down;
	Matrix<double, 6, 1> LL_Compensation_Support_ankle_up;
	Matrix<double, 6, 1> LL_Compensation_Support_ankle_down;
	double LL_Swing_Leg_Compensation_up(double t);
	double LL_Swing_Leg_Compensation_down(double t);
	double LL_Support_Leg_Compensation_up(double t);
	double LL_Support_Leg_Compensation_down(double t);
	double LL_Support_Knee_Compensation_up(double t);
	double LL_Support_Knee_Compensation_down(double t);
	double LL_Support_Ankle_Compensation_up(double t);
	double LL_Support_Ankle_Compensation_down(double t);
	double LL_Support_Leg;
	double LL_Swing_Leg;
	double LL_Support_Knee;
	double LL_Support_Ankle;
	double Com_Height;

public:
	IK_Function();
	void Get_Step_n(double a);
	MatrixXd BRP_RL_Simulation(MatrixXd RFx, MatrixXd RFy, MatrixXd RFz);
	MatrixXd BRP_LL_Simulation(MatrixXd RFx, MatrixXd RFy, MatrixXd RFz);
    void BRP_Simulation(const MatrixXd& RFx, const MatrixXd& RFy, const MatrixXd& RFz, const MatrixXd& LFx, const MatrixXd& LFy, const MatrixXd& LFz, int Index_CNT);
	void Angle_Compensation(int indext, int size);
	void Fast_Angle_Compensation(int indext);
	void Angle_Compensation_test(int indext);
	void Set_Angle_Compensation(int walktime_n);
	void Change_Angle_Compensation(double RL_Support, double RL_Swing, double RL_Knee , double RL_Ankle, double LL_Support, double LL_Swing, double LL_Knee ,double LL_Ankle);
	double RL_th[6] = { 0.,0.,-0.610865,1.22173,0.610865,0. }, LL_th[6] = { 0.,0.,-0.610865,1.22173,0.610865, 0.};
	void Change_Com_Height(double h);
    
	double check_index;

};














#pragma once

#include <Eigen/Dense>
#include <array>
#include <algorithm>  // std::clamp

// === 컨트롤러가 쓰는 로봇 파라미터 (전역 상수) 선언 ===
//  -> 값 정의는 NewPattern.cpp에 있음
extern const double ROBOT_WIDTH;         // [m] 좌우 발 간격 기준
extern const double ROBOT_STAND_HEIGHT;  // [m] 지지 높이 (COM 기준)
extern const double ROBOT_SWING_HEIGHT;  // [m] 스윙 발 최대 들어올림 높이

namespace gait {

// 좌표 인덱스 (컨트롤러에서 _X_, _Y_, _Z_ 사용)
enum : int { _X_ = 0, _Y_ = 1, _Z_ = 2 };

// 보행 패턴 상태(컨트롤러가 참조하는 필드만 최소 정의)
struct PatternState {
  double time_st{0.0};                            // stance / step 시간

  std::array<int,2>    SW_FLAG{ {0, 0} };         // 0=stance, 1=swing
  std::array<int,2>    old_SW_FLAG{ {0, 0} };     // 이전 프레임 SW_FLAG
  std::array<double,2> SwingPhase{ {0.0, 0.0} };  // 각 다리 스윙 진행률 [0..1]

  // 스탠스 발의 기준 위치 (스탠스 시 그대로 사용)
  std::array<double,2> stanceXtraj{ {0.0, 0.0} };
  std::array<double,2> stanceYtraj{ {0.0, 0.0} };
  std::array<double,2> stanceZtraj{ {0.0, 0.0} };
};

// Quintic 보간 헬퍼 (컨트롤러에서 GC_.quintic(tau) 호출)
struct Quintic {
  static inline double quintic(double s) {
    s = std::clamp(s, 0.0, 1.0);
    // C2 연속 5차 블렌드: 6s^5 - 15s^4 + 10s^3
    return ((6.0*s - 15.0)*s + 10.0)*s*s*s;
  }
};

// 시작 시 1회 초기화 헬퍼(선택): 현재 발 위치로 스탠스 궤적을 초기화
inline void ResetPatternForFirstStep(PatternState& P,
                                     const Eigen::Matrix<double,3,2>& foot_now) {
  P.old_SW_FLAG = {0, 0};
  for (int leg = 0; leg < 2; ++leg) {
    P.stanceXtraj[leg] = foot_now(_X_, leg);
    P.stanceYtraj[leg] = foot_now(_Y_, leg);
    P.stanceZtraj[leg] = foot_now(_Z_, leg);
    P.SwingPhase[leg]  = 0.0;
  }
}

} // namespace gait

// 컨트롤러가 전역처럼 접근하는 심볼
extern gait::PatternState Pattern_;
extern gait::Quintic      GC_;
