#pragma once

#include <Eigen/Dense>
#include <string>
#include "dynamixel.hpp"
#include "WalkingPattern.hpp"

// 필요에 따라 ROS2 메시지 타입, 서비스 타입 헤더는 .cpp에서 추가 (여긴 선언만)

class Callback
{
public:
    // 모션 인덱스 enum
    enum class MotionIndex : int {
        kInitPose = 0,
        kForward2Step = 1,
        kLeft2Step = 2,
        kStepInPlace = 3,
        kRight2Step = 4,
        kForwardNStep = 5,
        kHuddleJump = 6,
        kForwardFast4Step = 7,
        kFwdUp = 8,
        kBwdUp = 9,
        kForwardHalfStep = 10,
        kLeftHalfStep = 11,
        kRightHalfStep = 12,
        kBackHalfStep = 13,
        kBack2Step = 33,
        kForward1Step = 14,
        kLeft6Step = 15,
        kRight6Step = 16,
        kSTART = 50,
        kNONE = 99,
        kShoot = 17,
        kReadyToThrow = 18,
        kRight1Step = 19,
        kLeft1Step = 20,
        kGrab = 30,
        kFINISH = 100,
        kHuddleJumpV2 = 55,
        kGen2Walking = 111,
        kPickingBall = 112
    };

    // 문자열 상수 (실행 중 값 변경 없음 → static const)
    static constexpr const char* kStrInitPose = "InitPose";
    static constexpr const char* kStrForward2Step = "Forward_2step";
    static constexpr const char* kStrForward1Step = "Forward_1step";
    static constexpr const char* kStrLeft2Step = "Left_2step";
    static constexpr const char* kStrStepInPlace = "Step_in_place";
    static constexpr const char* kStrRight2Step = "Right_2step";
    static constexpr const char* kStrForwardFast4Step = "ForWard_fast4step";
    static constexpr const char* kStrForwardNStep = "Forward_Nstep";
    static constexpr const char* kStrHuddleJump = "Huddle_Jump";
    static constexpr const char* kStrHuddleJumpV2 = "Huddle_Jump_V2";
    static constexpr const char* kStrForwardHalfStep = "Forward_Halfstep";
    static constexpr const char* kStrLeftHalfStep = "Left_Halfstep";
    static constexpr const char* kStrRightHalfStep = "Right_Halfstep";
    static constexpr const char* kStrBackHalfStep = "Back_Halfstep";
    static constexpr const char* kStrBack2Step = "Back_2step";
    static constexpr const char* kStrLeft6Step = "Left_6step";
    static constexpr const char* kStrRight6Step = "Right_6step";
    static constexpr const char* kStrFwdUp = "FWD_UP";
    static constexpr const char* kStrBwdUp = "BWD_UP";
    static constexpr const char* kStrSTART = "START";
    static constexpr const char* kStrNONE = "NONE";
    static constexpr const char* kStrTestMode = "TEST_MODE";
    static constexpr const char* kStrGen2Walking = "Gen2_Walking";
    static constexpr const char* kStrShoot = "Shoot";
    static constexpr const char* kStrReadyToThrow = "Ready_to_throw";
    static constexpr const char* kStrLeft1Step = "Left_1step";
    static constexpr const char* kStrRight1Step = "Right_1step";
    static constexpr const char* kStrPickingBall = "Picking_Ball";
    static constexpr const char* kStrFINISH = "FINISH";

    // 생성자
    Callback(Trajectory* trajectory_ptr, IK_Function* ik_ptr, Dxl* dxl_ptr, Pick* pick_ptr);

    // 주요 멤버 포인터 (raw pointer 그대로 유지, 가능하면 unique/shared_ptr 권장)
    Trajectory* trajectory_ptr_;
    IK_Function* ik_ptr_;
    Dxl* dxl_ptr_;
    Pick* pick_ptr_;

    // Core Function
    virtual void WriteAllTheta();
    virtual void CheckFSR();
    void CalculateRealCP(int indext, double vx, double vy);
    void CalculateZMPFromCP(int indext);

    // IMU 관련 (thread 관련 기능은 cpp에서 std::thread 사용)
    void IMUThread();
    virtual void VelocityCallback(float imu);

    // 조인트/센서 관련
    virtual void JointStatesCallback(const Eigen::VectorXd& joint_command);
    virtual void LFSRSensorCallback(uint8_t fsr);
    virtual void RFSRSensorCallback(uint8_t fsr);
    virtual void StartMode(bool start);

    // 서비스/콜백
    virtual int GenerateUniqueRequestID();

    virtual void SelectMotion();
    virtual void MoveUDNeckAngle();
    virtual void MoveRLNeckAngle();
    virtual void TATA();
    virtual void Emergency();
    virtual void MotionInfo();
    virtual void ReceiveMotion();

    // 변수들
    static constexpr int kSpinRate = 100;
    Eigen::VectorXd goal_joint_ = Eigen::VectorXd::Zero(kNumberOfDynamixels);
    uint8_t l_value_ = 0;
    uint8_t r_value_ = 0;
    uint8_t fsr_value_[2] = {l_value_, r_value_};
    double rl_neck_angle_ = 0;
    double ud_neck_angle_ = 0;
    double tmp_turn_angle_ = 0;
    bool emergency_ = true;
    double vel_x_ = 0, vel_y_ = 0, vel_z_ = 0;
    int error_counter_ = 0;
    bool error_printed_ = false;
    int8_t mode_ = 99; // NONE
    double walkfreq_ = 1.48114;
    double walktime_ = 2 / walkfreq_;
    int freq_ = 100;
    int walktime_n_ = walktime_ * freq_;
    int indext_ = 0;
    int upper_indext_ = 0;
    int check_indext_ = 0;
    int stop_indext_ = 0;
    bool turn_left_ = false;
    bool turn_right_ = false;
    int emergency_val_ = 99;
    bool on_emergency_ = false;
    double angle_ = 0;
    int index_angle_ = 0;
    double step_ = 0;
    double rl_th2_ = 0, ll_th2_ = 0;
    double rl_th1_ = 0, ll_th1_ = 0;
    double hs_ = 0, sr_ = 0;

    Eigen::MatrixXd rl_motion_, ll_motion_;
    Eigen::MatrixXd rl_motion0_, ll_motion0_;
    Eigen::MatrixXd rl_motion1_, ll_motion1_;
    Eigen::MatrixXd rl_motion2_, ll_motion2_;
    Eigen::MatrixXd rl_motion3_, ll_motion3_;
    Eigen::MatrixXd rl_motion4_, ll_motion4_;
    Eigen::MatrixXd rl_motion5_, ll_motion5_;
    Eigen::MatrixXd rl_motion6_, ll_motion6_;
    Eigen::MatrixXd rl_motion7_, ll_motion7_;
    Eigen::VectorXd all_theta_ = Eigen::MatrixXd::Zero(kNumberOfDynamixels, 1);

    // CP/ZMP
    double real_cp_y_ = 0, real_cp_x_ = 0;
    double xzmp_from_cp_ = 0, yzmp_from_cp_ = 0;
    double real_zmp_y_accel_ = 0;

private:
    double turn_angle_ = 0;
    int arm_indext_ = 0;
    double z_c_ = 1.2 * 0.28224;
    double g_ = 9.81;
    double omega_w_;
    double dt_ = 0.01;
    Eigen::MatrixXd huddle_rl_theta_, huddle_ll_theta_;
};
