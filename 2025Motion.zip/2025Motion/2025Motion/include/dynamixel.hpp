#ifndef DYNAMIXEL_H
#define DYNAMIXEL_H

#include <Eigen/Dense>
#include <vector>
#include <cstdint>
#include <dynamixel_sdk/dynamixel_sdk.h> // ROBOTIS Dynamixel SDK

// Protocol version
constexpr double kProtocolVersion = 2.0;

// Default setting
constexpr int kNumberOfDynamixels = 23;
constexpr int kBaudrate = 4000000;
constexpr char kDeviceName[] = "/dev/ttyUSB0";

// Math constants
constexpr double kPi = 3.141592;
constexpr double kTorqueToValueMx64 = 267.094;
constexpr double kTorqueToValueMx106 = 183.7155;
constexpr double kRadToValue = 651.89878; // 1rev = 4096 --> 4096/(2*PI)
constexpr double kRad2Deg = 57.2958;
constexpr double kDeg2Rad = 0.0174533;

// Operating Mode
enum class DynamixelOperatingMode : int16_t {
    kCurrentControlMode = 0,
    kVelocityControlMode = 1,
    kPositionControlMode = 3,
    kExtendedPositionControlMode = 4,
    kCurrentBasedPositionControlMode = 5,
    kPWMControlMode = 16
};

// Control table address
enum class DynamixelStandardRegisterTable : uint16_t {
    // EEPROM
    kModelNumber = 0,
    kModelInfo = 2,
    kFirmwareVersion = 6,
    kID = 7,
    kBaudRate = 8,
    kReturnDelayTime = 9,
    kDriveMode = 10,
    kOperatingMode = 11,
    kShadowID = 12,
    kProtocolVersion = 13,
    kHomingOffset = 20,
    kMovingThreshold = 24,
    kTemperatureLimit = 31,
    kMaxVoltageLimit = 32,
    kMinVoltageLimit = 34,
    kPWMLimit = 36,
    kCurrentLimit = 38,
    kAccelerationLimit = 40,
    kVelocityLimit = 44,
    kMaxPositionLimit = 48,
    kMinPositionLimit = 52,
    kDataPort1Mode = 56,
    kDataPort2Mode = 57,
    kDataPort3Mode = 58,
    kShutdown = 63,

    // RAM
    kTorqueEnable = 64,
    kLED = 65,
    kStatusReturnLevel = 68,
    kRegisteredInstruction = 69,
    kHardwareErrorStatus = 70,
    kVelocityIGain = 76,
    kVelocityPGain = 78,
    kPositionDGain = 80,
    kPositionIGain = 82,
    kPositionPGain = 84,
    kFeedforward2ndGain = 88,
    kFeedforward1stGain = 90,
    kBusWatchdog = 98,
    kGoalPWM = 100,
    kGoalCurrent = 102,
    kGoalVelocity = 104,
    kProfileAcceleration = 108,
    kProfileVelocity = 112,
    kGoalPosition = 116,
    kRealtimeTick = 120,
    kMoving = 122,
    kMovingStatus = 123,
    kPresentPWM = 124,
    kPresentCurrent = 126,
    kPresentVelocity = 128,
    kPresentPosition = 132,
    kVelocityTrajectory = 136,
    kPositionTrajectory = 140,
    kPresentInputVoltage = 144,
    kPresentTemperature = 146,
    kDataPort1 = 152,
    kDataPort2 = 154,
    kDataPort3 = 156,
    kIndirectAddress1 = 168,
    kIndirectData1 = 224
};

class Dxl
{
public:
    Dxl();
    virtual ~Dxl();

    // Getters
    virtual Eigen::VectorXd GetThetaAct();
    virtual Eigen::VectorXd GetThetaDot();
    virtual Eigen::VectorXd GetThetaDotEstimated();
    virtual int16_t GetPresentMode();
    virtual void syncReadTheta();
    virtual void SyncReadCurrent();
    virtual Eigen::VectorXd GetCurrent();

    // Setters
    virtual void SetTorqueRef(const Eigen::VectorXd&);
    virtual void SetThetaRef(const Eigen::VectorXd&);
    virtual int16_t SetPresentMode(int16_t Mode);
    virtual void syncWriteTheta();
    void SetPIDGain(const Eigen::VectorXd& PID_Gain);

    // Function
    virtual void Loop(bool RxTh, bool RxThDot, bool TxTorque);
    virtual void CalculateEstimatedThetaDot(int);
    virtual void initActuatorValues();
    virtual float convertValue2Current(int32_t value);
    float convertValue2Radian(int32_t value);
    int32_t torqueToValue(double torque, uint8_t index);

    // Public member variables (snake_case with trailing underscore for private, public if necessary)
    Eigen::VectorXd th_ = Eigen::VectorXd::Zero(kNumberOfDynamixels);
    Eigen::VectorXd cur_ = Eigen::VectorXd::Zero(kNumberOfDynamixels);

private:
    // Dynamixel SDK handlers
    dynamixel::PortHandler* port_handler_;
    dynamixel::PacketHandler* packet_handler_;
    const uint8_t dxl_id_[kNumberOfDynamixels] = {
        10, 8, 6, 4, 2, 0, 11, 9, 7, 5, 3, 1, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22
    };
    float zero_manual_offset_[kNumberOfDynamixels] = {0};
    uint32_t position_[kNumberOfDynamixels] = {0};
    uint32_t velocity_[kNumberOfDynamixels] = {0};
    int32_t ref_torque_value_[kNumberOfDynamixels] = {0};
    int32_t torque2value_[kNumberOfDynamixels] = {0};
    uint32_t current_[kNumberOfDynamixels] = {0};

    Eigen::VectorXd ref_th_value_ = Eigen::VectorXd::Zero(kNumberOfDynamixels);
    Eigen::VectorXd ref_th_ = Eigen::VectorXd::Zero(kNumberOfDynamixels);
    Eigen::VectorXd ref_th_dot_ = Eigen::VectorXd::Zero(kNumberOfDynamixels);
    Eigen::VectorXd ref_torque_ = Eigen::VectorXd::Zero(kNumberOfDynamixels);
    Eigen::VectorXd th_last_ = Eigen::VectorXd::Zero(kNumberOfDynamixels);
    Eigen::VectorXd th_dot_ = Eigen::VectorXd::Zero(kNumberOfDynamixels);
    Eigen::VectorXd th_dot_est_ = Eigen::VectorXd::Zero(kNumberOfDynamixels);

    int16_t mode_ = 1; // Current = 0, Position = 1

    // Private functions (move here if not intended for public)
    virtual void syncReadThetaDot();
    virtual void getParam(int32_t data, uint8_t *param);
    virtual void syncWriteTorque();
};

#endif // DYNAMIXEL_H
