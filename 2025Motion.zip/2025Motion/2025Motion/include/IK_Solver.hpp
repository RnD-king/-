#pragma once
#include <eigen3/Eigen/Dense>

// Right leg IK
Eigen::VectorXd BRP_RL_IK(
    const Eigen::VectorXd& Ref_RF_PR,     // 목표 발끝 위치/자세 [x, y, z, yaw, pitch, roll]
    const Eigen::VectorXd& InitAng,       // 초기 관절각 (6x1)
    double L0, double L3, double L4, double L6
);

// Left leg IK
Eigen::VectorXd BRP_LL_IK(
    const Eigen::VectorXd& Ref_LF_PR,     // 목표 발끝 위치/자세 [x, y, z, yaw, pitch, roll]
    const Eigen::VectorXd& InitAng,       // 초기 관절각 (6x1)
    double L0, double L3, double L4, double L6
);

// DH변환 행렬 함수 - just ref.
Eigen::Matrix4d DH(double a, double alpha, double d, double theta);
